


source /home/xsdk_2018.3_settings64.sh
export CROSS_COMPILE=arm-linux-gnueabihf-

${CROSS_COMPILE}gcc -g -static app_bandwidth.c -o app_bandwidth.elf -pthread -lm



