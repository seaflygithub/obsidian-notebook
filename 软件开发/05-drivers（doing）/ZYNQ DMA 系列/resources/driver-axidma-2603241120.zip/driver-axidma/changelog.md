


- axidma_v007.c
  - 文件列表
    - 公共文件: axidma_common.h
    - 驱动文件: axidma_v007.c、Makefile、build_drv.sh
    - 应用程序: app_bandwidth.c、build_app.sh
  - [x] 使用 DEFINE_IDA 管理 AXIDMA 实例ID
  - [x] 每个 AXIDMA 实例都有3个用户空间设备节点(cdev_h2c, cdev_c2h, cdev_ctr)
  - [x] 内存方式: dma_alloc_coherent + dma_mmap_coherent
  - [x] read/write 随机位置访问（通过把 read/write 的 buf 参数作为偏移来访问）
  - [x] read/write 阻塞式读写, 可通过 Ctrl+C 终止
  - [ ] 采用官方裸机的 BdRing 无锁管理算法(ToHw, FromHw, ...)。

