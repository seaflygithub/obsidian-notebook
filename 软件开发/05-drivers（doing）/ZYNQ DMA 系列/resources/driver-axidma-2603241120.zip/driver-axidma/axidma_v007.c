﻿
#include <linux/module.h>
#include <linux/init.h>

#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_device.h>

#include <linux/dmaengine.h>
#include <linux/dma-mapping.h>

#include <linux/completion.h>
#include <linux/slab.h>
#include <linux/gfp.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/idr.h> // 多个IP实例设备号申请和释放, 比如 axidma0_xxx, axidma1_xxx, ...
#include <linux/uaccess.h>

#include <linux/scatterlist.h>

#include <linux/errno.h>
#include <linux/err.h>

#include <linux/jiffies.h>
#include <linux/time.h>

#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/printk.h>
#include <linux/string.h>
#include <linux/ctype.h>
#include <linux/limits.h>

#include "axidma_common.h"

#define DRV_MODULE_NAME "axidma"
#define DEFAULT_BUFSZ (6*1024*1024UL)

struct axidma_buf {
    void *cpu_addr;
    dma_addr_t dma_addr;
    size_t size;
};

struct szsywhf_axidma_device {

    // 下面带 axidma_前缀的, 都属于该实例内公共部分

    /*
      每个实例都有自己的编号, ida分配, 比如设备实例号（0,1,2,...), 
      比如 /dev/axidma0_xxx, /dev/axidma1_xxx
    **/
    int axidma_id;

    // 其中 "axidma0" 中的 0 就来自于 axidma_id
    char axidma_classname[16];    // 比如 "axidma0" --> /sys/class/axidma0
    char axidma_devname_h2c0[16]; // 比如 "axidma0_h2c_0" --> /dev/axidma0_h2c_0
    char axidma_devname_c2h0[16]; // 比如 "axidma0_c2h_0" --> /dev/axidma0_c2h_0
    char axidma_devname_user[16]; // 比如 "axidma0_usr" --> /dev/axidma0_user

    // 该实例的起始设备号
    dev_t axidma_devno;



    // 该实例的设备类
    struct class *axidma_class;
    
    struct platform_device *pdev;

    struct dma_chan *tx_chan;
    struct dma_chan *rx_chan;
    struct axidma_buf tx; // 存放着初分配(dma_alloc_coherent)的内存信息
    struct axidma_buf rx; // 存放着初分配(dma_alloc_coherent)的内存信息
    struct completion tx_cmp;
    struct completion rx_cmp;

    // 用来协助带宽测试
    u64 tx_total_ns;// unit: nano second
    u64 rx_total_ns;// unit: nano second
    u64 tx_total_bytes;
    u64 rx_total_bytes;
    
    /* 3个设备节点 */
    struct cdev cdev_h2c; // 用于数据发送
    struct cdev cdev_c2h; // 用于数据接收
    struct cdev cdev_ctr; // 用于控制指令和寄存器读写
};

// 用 ID 分配器 来管理axidma实例编号, 比 atomic++ 更规范，支持释放
static DEFINE_IDA(axidma_ida);

// 所有 axidma 实例共用一个类
// static struct class *axidma_class;

static int max_timeout_ms = 30000;
static long tx_bufsz = DEFAULT_BUFSZ;
static long rx_bufsz = DEFAULT_BUFSZ;
static char tx_bufsz_str[64] = "2MB";
static char rx_bufsz_str[64] = "2MB";

// insmod xxx.ko max_timeout_ms=30000
module_param(max_timeout_ms, int, 0644);

// insmod xxx.ko tx_bufsize=2MB rx_bufsize=2MB
module_param_string(tx_bufsize, tx_bufsz_str, 64, 0644);
module_param_string(rx_bufsize, rx_bufsz_str, 64, 0644);


uintptr_t inline cpu_addr_offset(const void *cpu_bigaddr, const void *cpu_subaddr)
{
    // cpu_subaddr 是在 cpu_bigaddr 范围内, 所以是 sub-big
    return (uintptr_t)cpu_subaddr - (uintptr_t)cpu_bigaddr;
}

/**
 * @brief 快速判断subbuf指向的地址是否在bigbuf的内存范围内
 * @param bigbuf 大缓冲区起始地址（不可为NULL）
 * @param bufsz  大缓冲区的字节长度（≥0）
 * @param subbuf 待检查的地址（不可为NULL）
 * @return true：subbuf在bigbuf范围内；false：不在范围内/参数非法
 * @note 1. 仅检查地址归属，不保证subbuf指向的内存可访问（需调用方确保bigbuf有效）
 *       2. 地址比较基于指针的数值大小，仅适用于同一连续内存块的判断
 */
bool is_addr_in_buf(const void *bigbuf, size_t bufsz, const void *subbuf) {
    uintptr_t big_start;
    uintptr_t big_end;
    uintptr_t sub_addr;

    // 1. 空指针/空缓冲区直接返回false
    if (bigbuf == NULL || subbuf == NULL || bufsz == 0) {
        return false;
    }

    // 2. 将指针转换为uintptr_t（无符号整数类型，专门用于地址运算）
    //    避免void*直接加减/比较的编译器警告
    big_start = (uintptr_t)bigbuf;
    big_end   = big_start + bufsz; // 缓冲区结束地址（开区间）
    sub_addr  = (uintptr_t)subbuf;

    // 3. 核心判断：sub_addr ∈ [big_start, big_end)
    return (sub_addr >= big_start) && (sub_addr < big_end);
}

/**
 * @brief 判断subbuf起始地址到subbuf+subsz的区间是否全部在bigbuf范围内
 * @param bigbuf 大缓冲区起始地址
 * @param bufsz  大缓冲区字节长度
 * @param subbuf 子缓冲区起始地址
 * @param subsz  子缓冲区字节长度
 * @return true：子缓冲区完全在大缓冲区内；false：否则
 */
bool is_range_in_buf(const void *bigbuf, size_t bufsz, 
                     const void *subbuf, size_t subsz) {
    uintptr_t sub_end;

    // 子缓冲区为空，默认合法（或根据需求改为false）
    if (subsz == 0) {
        return true;
    }
    // 先判断subbuf起始地址合法
    if (!is_addr_in_buf(bigbuf, bufsz, subbuf)) {
        return false;
    }
    // 再判断subbuf+subsz-1（子缓冲区最后一个字节）是否合法
    sub_end = (uintptr_t)subbuf + subsz - 1;
    return is_addr_in_buf(bigbuf, bufsz, (const void *)sub_end);
}

static void tx_cb(void *param)
{
    complete(param);
}

static void rx_cb(void *param)
{
    complete(param);
}

static int axidma_h2c_mmap(struct file *file,
                           struct vm_area_struct *vma)
{
    struct szsywhf_axidma_device *dev = file->private_data;

    if (dev->tx.size <= 0)
    {
        pr_warn("This channel is not supported by the driver at installation time.\n");
        return -ENXIO;
    }

    /*
      (1) 如果应用程序想映射 1MB 内存, 那么该 h2c 通道就有 1MB 连续物理内存;

      (2) 如果应用程序想映射 多个 1MB 内存, 比如 64 个, 
      则直接映射 64MB 连续物理内存,
      然后应用程序收发数据时由应用程序来管理偏移和指定偏移, 
      比如应用程序此刻要把 h2c 的 buf[64*1MB] 的 [16*1MB] 里的数据发送给 Stream 设备,
      那么伪代码如: write(fd_h2c, &buf[16*1MB], 1MB); 该用法同理于 c2h。

      (3) 上述(2)里由应用程序管理多个连续物理地址, 
      这些多个连续物理地址可以组织串成 Ring,  
      可以把官方裸机代码里 BdRing 那套无锁管理的代码移植到用户空间，
      作为应用层的库提供给用户使用, 以满足用户对 Ring 的需求。

    **/

    return dma_mmap_coherent(&dev->pdev->dev,
                             vma,
                             dev->tx.cpu_addr,
                             dev->tx.dma_addr,
                             dev->tx.size);
}

static int axidma_c2h_mmap(struct file *file,
                           struct vm_area_struct *vma)
{
    struct szsywhf_axidma_device *dev = file->private_data;

    if (dev->rx.size <= 0)
    {
        pr_warn("This channel is not supported by the driver at installation time.\n");
        return -ENXIO;
    }

    return dma_mmap_coherent(&dev->pdev->dev,
                             vma,
                             dev->rx.cpu_addr,
                             dev->rx.dma_addr,
                             dev->rx.size);
}

static int start_tx_dma(struct szsywhf_axidma_device *dev,
    uintptr_t buf_offset,
    size_t user_req_size
)
{
	int ret;
    struct dma_async_tx_descriptor *txd;

    reinit_completion(&dev->tx_cmp);
    txd = dmaengine_prep_slave_single(
        dev->tx_chan,
        dev->tx.dma_addr + buf_offset,
        user_req_size,
        DMA_MEM_TO_DEV,
        DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    // txd = dmaengine_prep_slave_single(
    //     dev->tx_chan,
    //     dev->tx.dma_addr,
    //     dev->tx.size,
    //     DMA_MEM_TO_DEV,
    //     DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!txd)
        return -ENOMEM;

    txd->callback = tx_cb;
    txd->callback_param = &dev->tx_cmp;

    dmaengine_submit(txd);
    dma_async_issue_pending(dev->tx_chan);

    // wait_for_completion_timeout(&dev->tx_cmp, msecs_to_jiffies(30000));
    ret = wait_for_completion_interruptible_timeout(&dev->tx_cmp, msecs_to_jiffies(max_timeout_ms));
	//printk("%s:wait ret is %d\n", __func__, ret);
	// 根据实际打印调试得知, 如果超时则返回值为0, 否则就是一个正整数
	if (ret == 0) {
		pr_warn("%s: timeout (max_timeout_ms=%d)\n", __func__, max_timeout_ms);
		return -ETIMEDOUT;
	}

    return 0;
}

static int start_rx_dma(struct szsywhf_axidma_device *dev,
    uintptr_t buf_offset,
    size_t user_req_size
)
{
	int ret;
    struct dma_async_tx_descriptor *rxd;

    reinit_completion(&dev->rx_cmp);
    rxd = dmaengine_prep_slave_single(
        dev->rx_chan,
        dev->rx.dma_addr + buf_offset,
        user_req_size,
        DMA_DEV_TO_MEM,
        DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    // rxd = dmaengine_prep_slave_single(
    //     dev->rx_chan,
    //     dev->rx.dma_addr,
    //     dev->rx.size,
    //     DMA_DEV_TO_MEM,
    //     DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!rxd)
        return -ENOMEM;

    rxd->callback = rx_cb;
    rxd->callback_param = &dev->rx_cmp;

    dmaengine_submit(rxd);
    dma_async_issue_pending(dev->rx_chan);

    // wait_for_completion_timeout(&dev->rx_cmp, msecs_to_jiffies(30000));
    ret = wait_for_completion_interruptible_timeout(&dev->rx_cmp, msecs_to_jiffies(max_timeout_ms));
	//printk("%s:wait ret is %d\n", __func__, ret);
	// 根据实际打印调试得知, 如果超时则返回值为0, 否则就是一个正整数
	if (ret == 0) {
		pr_warn("%s: timeout (max_timeout_ms=%d)\n", __func__, max_timeout_ms);
		return -ETIMEDOUT;
	}
	
    return 0;
}

static ssize_t axidma_h2c_write(struct file *file,
                         const char __user *buf,
                         size_t len,
                         loff_t *off)
{
    ktime_t t_start, t_end;
    u64 ns;

    ssize_t retlen;
    struct szsywhf_axidma_device *dev = file->private_data;

    if (dev->tx.size <= 0)
    {
        pr_warn("This channel is not supported by the driver at installation time.\n");
        return -ENXIO;
    }

    // 初分配的内存信息
    // dev->tx.size;
    // dev->tx.cpu_addr;
    // dev->tx.dma_addr;

    // 用户buf直接作为偏移
    // buf;

    // 判断用户传入地址范围是否合法
    if (!is_range_in_buf(
        (const void *)(dev->tx.cpu_addr), 
        dev->tx.size,
        (const void *)((uintptr_t)(dev->tx.cpu_addr) + (uintptr_t)buf), 
        len
    ))
    {
        pr_err("buf + size is out of range [0x%lx, 0x%lx), "
            "current buf offset is 0x%lx, size is 0x%lx\n",
            (uintptr_t)(dev->tx.cpu_addr),
            (uintptr_t)(dev->tx.cpu_addr) + dev->tx.size,
            (uintptr_t)buf,
            (uintptr_t)len
        );
        return -EINVAL;// 无效参数
    }

    t_start = ktime_get();

    retlen = start_tx_dma(dev, (uintptr_t)buf, len);
    if (retlen == 0)
        retlen = len;

    t_end = ktime_get();
    ns = ktime_to_ns(ktime_sub(t_end, t_start));
    dev->tx_total_ns += ns;
    dev->tx_total_bytes += (retlen>0? retlen:0);

    return retlen;
}

static ssize_t axidma_c2h_read(struct file *file,
                        char __user *buf,
                        size_t len,
                        loff_t *off)
{
    ktime_t t_start, t_end;
    u64 ns;

    ssize_t retlen;
    struct szsywhf_axidma_device *dev = file->private_data;

    if (dev->rx.size <= 0)
    {
        pr_warn("This channel is not supported by the driver at installation time.\n");
        return -ENXIO;
    }

    // 初分配的内存信息
    // dev->rx.size;
    // dev->rx.cpu_addr;
    // dev->rx.dma_addr;

    // 用户buf直接作为偏移
    // buf;

    // 判断用户传入地址范围是否合法
    if (!is_range_in_buf(
        (const void *)(dev->rx.cpu_addr), 
        dev->rx.size,
        (const void *)((uintptr_t)(dev->rx.cpu_addr) + (uintptr_t)buf), 
        len
    ))
    {
        pr_err("buf + size is out of range [0x%lx, 0x%lx), "
            "current buf offset is 0x%lx, size is 0x%lx\n",
            (uintptr_t)(dev->rx.cpu_addr),
            (uintptr_t)(dev->rx.cpu_addr) + dev->rx.size,
            (uintptr_t)buf,
            (uintptr_t)len
        );
        return -EINVAL;// 无效参数
    }

    t_start = ktime_get();

    retlen = start_rx_dma(dev, (uintptr_t)buf, len);
    if (retlen == 0)
        retlen = len;

    t_end = ktime_get();
    ns = ktime_to_ns(ktime_sub(t_end, t_start));
    dev->rx_total_ns += ns;
    dev->rx_total_bytes += (retlen>0? retlen:0);

    return retlen;
}


static long axidma_ioctl(struct file *file,
                         unsigned int cmd,
                         unsigned long arg)
{
    int ret;
    u64 perf_results[4]; // tx(2) + rx(2)
    struct szsywhf_axidma_device *dev = file->private_data;

    switch (cmd) {


    // 这两个性能相关的命令, 主要作用是在驱动层面统计每次调用 read/write 耗时,
    // 最后把他们的总耗时汇总给用户空间,
    // 用来从驱动层面计算带宽, 协助用户空间做对比 (比如系统调用耗时占比等)
    // 公式: total_bytes*1e9/total_ns/1024/1024 = xxx MB/s
    // 或者: total_bytes*1e6/total_us/1024/1024 = xxx MB/s

    case AXIDMA_IOCTL_PERF_BEGIN:
    {
        dev->tx_total_ns = 0;
        dev->rx_total_ns = 0;
        dev->tx_total_bytes = 0;
        dev->rx_total_bytes = 0;
        return 0;
    }

    case AXIDMA_IOCTL_PERF_END:
    {
        perf_results[0] = dev->tx_total_ns;
        perf_results[1] = dev->rx_total_ns;
        perf_results[2] = dev->tx_total_bytes;
        perf_results[3] = dev->rx_total_bytes;

        ret = copy_to_user((long __user *)arg, 
                perf_results, sizeof(perf_results));
        return ret;
    }

    default:
        return -EINVAL;
    }
}

static int axidma_open_ctrl(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_ctr);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static int axidma_h2c_open(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_h2c);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static int axidma_c2h_open(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_c2h);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static ssize_t reg_read(struct file *file,
                        char __user *buf,
                        size_t len,
                        loff_t *off)
{
    struct szsywhf_axidma_device *dev = file->private_data;
    // u32 value;
    // size_t reg_idx;

    // if (*off % 4 != 0)
    //     return -EINVAL;

    // reg_idx = *off / 4;

    // if (reg_idx >= 256)
    //     return -EINVAL;

    // value = dev->regs[reg_idx];

    // if (len > sizeof(u32))
    //     len = sizeof(u32);

    // if (copy_to_user(buf, &value, len))
    //     return -EFAULT;

    // *off += len;

    return len;
}

static ssize_t reg_write(struct file *file,
                         const char __user *buf,
                         size_t len,
                         loff_t *off)
{
    struct szsywhf_axidma_device *dev = file->private_data;
    // u32 value;
    // size_t reg_idx;

    // if (*off % 4 != 0)
    //     return -EINVAL;

    // reg_idx = *off / 4;

    // if (reg_idx >= 256)
    //     return -EINVAL;

    // if (len > sizeof(u32))
    //     len = sizeof(u32);

    // if (copy_from_user(&value, buf, len))
    //     return -EFAULT;

    // dev->regs[reg_idx] = value;

    // pr_debug("reg_write: [%zu] = 0x%x\n", reg_idx, value);

    // *off += len;

    return len;
}


static const struct file_operations h2c_fops = {
    .owner = THIS_MODULE,
    .mmap  = axidma_h2c_mmap,
    .open  = axidma_h2c_open,
    .write = axidma_h2c_write,
};

static const struct file_operations c2h_fops = {
    .owner = THIS_MODULE,
    .mmap  = axidma_c2h_mmap,
    .open  = axidma_c2h_open,
    .read  = axidma_c2h_read,
};

static const struct file_operations ctrl_fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = axidma_ioctl,
    .read           = reg_read,
    .write          = reg_write,
    .open           = axidma_open_ctrl,
};

static int axidma_probe(struct platform_device *pdev)
{
    struct szsywhf_axidma_device *dev;
    int ret;

    pr_info("called %s\n", __func__);

    // 为当前AXI DMA IP核生成一个独立的实例
    dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
    if (!dev)
        return -ENOMEM;

    init_completion(&dev->tx_cmp);
    init_completion(&dev->rx_cmp);

    /* ================= DMA channels ================= */
    dev->tx_chan = dma_request_chan(&pdev->dev, "tx_channel");
    if (IS_ERR(dev->tx_chan)) {
        ret = PTR_ERR(dev->tx_chan);
        pr_err("failed to get tx channel\n");
        return ret;
    }

    dev->rx_chan = dma_request_chan(&pdev->dev, "rx_channel");
    if (IS_ERR(dev->rx_chan)) {
        ret = PTR_ERR(dev->rx_chan);
        pr_err("failed to get rx channel\n");
        goto err_tx_chan;
    }

    // 分配实例ID
    dev->axidma_id = ida_alloc(&axidma_ida, GFP_KERNEL);
    if (dev->axidma_id < 0) {
        pr_err("failed to alloc device id(use ida_alloc) %d\n", dev->axidma_id);
        goto err_ida;
    }
    snprintf(dev->axidma_classname, sizeof(dev->axidma_classname), "axidma%d", dev->axidma_id);
    snprintf(dev->axidma_devname_h2c0, sizeof(dev->axidma_devname_h2c0), "axidma%d_h2c_0", dev->axidma_id);
    snprintf(dev->axidma_devname_c2h0, sizeof(dev->axidma_devname_c2h0), "axidma%d_c2h_0", dev->axidma_id);
    snprintf(dev->axidma_devname_user, sizeof(dev->axidma_devname_user), "axidma%d_user", dev->axidma_id);

    dev->pdev = pdev;
    platform_set_drvdata(pdev, dev);

    
    // 拿到用户空间 insmod 传入的参数
    tx_bufsz = str_to_bytes(tx_bufsz_str, NULL, 0);
    if (tx_bufsz < 0) {
        pr_warn("[tx_bufsz_str=%s] parse insmod tx_bufsize failed, use default size %ld\n", 
            tx_bufsz_str, DEFAULT_BUFSZ);
        tx_bufsz = DEFAULT_BUFSZ;
    }

    rx_bufsz = str_to_bytes(rx_bufsz_str, NULL, 0);
    if (rx_bufsz < 0) {
        pr_warn("[rx_bufsz_str=%s] parse insmod tx_bufsize failed, use default size %ld\n", 
            rx_bufsz_str, DEFAULT_BUFSZ);
        rx_bufsz = DEFAULT_BUFSZ;
    }

    /* ================= DMA buffer ================= */
    dev->tx.size = tx_bufsz;
    dev->rx.size = rx_bufsz;

    // 表示用户装驱动时不打算用该通道, 则会在安装驱动时把对应的 bufsz 参数设为0
    if (dev->tx.size > 0)
    {
        dev->tx.cpu_addr =
            dma_alloc_coherent(&pdev->dev,
                            dev->tx.size,
                            &dev->tx.dma_addr,
                            GFP_KERNEL);
        if (!dev->tx.cpu_addr) {
            ret = -ENOMEM;
            pr_err("dma_alloc_coherent tx failed (ENOMEM)\n");
            goto err_rx_chan;
        }
    }

    if (dev->rx.size > 0)
    {
        dev->rx.cpu_addr =
            dma_alloc_coherent(&pdev->dev,
                            dev->rx.size,
                            &dev->rx.dma_addr,
                            GFP_KERNEL);
        if (!dev->rx.cpu_addr) {
            ret = -ENOMEM;
            pr_err("dma_alloc_coherent rx failed (ENOMEM)\n");
            goto err_tx_buf;
        }
    }

    /* ================= char device ================= */

    ret = alloc_chrdev_region(&dev->axidma_devno, 0, 3, dev->axidma_classname);
    if (ret) {
        pr_err("alloc_chrdev_region failed\n");
        goto err_rx_buf;
    }

    /* ---- h2c cdev ---- */
    cdev_init(&dev->cdev_h2c, &h2c_fops);
    dev->cdev_h2c.owner = THIS_MODULE;
    ret = cdev_add(&dev->cdev_h2c, dev->axidma_devno + 0, 1);
    if (ret) {
        pr_err("cdev_add h2c failed\n");
        goto err_cdev_ctr;
    }

    /* ---- c2h cdev ---- */
    cdev_init(&dev->cdev_c2h, &c2h_fops);
    dev->cdev_c2h.owner = THIS_MODULE;
    ret = cdev_add(&dev->cdev_c2h, dev->axidma_devno + 1, 1);
    if (ret) {
        pr_err("cdev_add c2h failed\n");
        goto err_cdev_h2c;
    }

    /* ---- ctrl cdev ---- */
    cdev_init(&dev->cdev_ctr, &ctrl_fops);
    dev->cdev_ctr.owner = THIS_MODULE;
    ret = cdev_add(&dev->cdev_ctr, dev->axidma_devno + 2, 1);
    if (ret) {
        pr_err("cdev_add ctrl failed\n");
        goto err_unregister_chrdev;
    }

    // 3个设备节点同属一个类
    dev->axidma_class = class_create(THIS_MODULE, dev->axidma_classname);
    if (IS_ERR(dev->axidma_class)) {
        ret = PTR_ERR(dev->axidma_class);
        goto err_cdev_c2h;
    }

    if (!device_create(dev->axidma_class, NULL, 
        dev->axidma_devno + 0, dev, dev->axidma_devname_h2c0)) 
    {
        ret = -EINVAL;
        goto err_class;
    }

    if (!device_create(dev->axidma_class, NULL, 
        dev->axidma_devno + 1, dev, dev->axidma_devname_c2h0)) 
    {
        ret = -EINVAL;
        goto err_dev_h2c;
    }

    if (!device_create(dev->axidma_class, NULL, 
        dev->axidma_devno + 2, dev, dev->axidma_devname_user)) 
    {
        ret = -EINVAL;
        goto err_dev_c2h;
    }

    pr_info("axidma probe success\n");
    return 0;

/* ================= error rollback ================= */

err_dev_c2h:
    device_destroy(dev->axidma_class, dev->axidma_devno + 1);

err_dev_h2c:
    device_destroy(dev->axidma_class, dev->axidma_devno + 0);

err_class:
    class_destroy(dev->axidma_class);
    
err_cdev_c2h:
    cdev_del(&dev->cdev_c2h);

err_cdev_h2c:
    cdev_del(&dev->cdev_h2c);

err_cdev_ctr:
    cdev_del(&dev->cdev_ctr);

err_unregister_chrdev:
    unregister_chrdev_region(dev->axidma_devno, 3);

err_rx_buf:
    if (dev->rx.size > 0) {
        dma_free_coherent(&pdev->dev,
                        dev->rx.size,
                        dev->rx.cpu_addr,
                        dev->rx.dma_addr);
    }


err_tx_buf:
    if (dev->tx.size > 0) {
        dma_free_coherent(&pdev->dev,
                        dev->tx.size,
                        dev->tx.cpu_addr,
                        dev->tx.dma_addr);
    }

err_ida:
    ida_free(&axidma_ida, dev->axidma_id);

err_rx_chan:
    dma_release_channel(dev->rx_chan);

err_tx_chan:
    dma_release_channel(dev->tx_chan);

    return ret;
}


static int axidma_remove(struct platform_device *pdev)
{
    struct szsywhf_axidma_device *dev = platform_get_drvdata(pdev);

    pr_info("remove axidma%d\n", dev->axidma_id);

    /* stop DMA */
    dmaengine_terminate_all(dev->tx_chan);
    dmaengine_terminate_all(dev->rx_chan);

    /* release DMA channels */
    dma_release_channel(dev->tx_chan);
    dma_release_channel(dev->rx_chan);

    /* free DMA buffers */
    if (dev->tx.size > 0) {
        if (dev->tx.cpu_addr) {
            dma_free_coherent(&pdev->dev,
                            dev->tx.size,
                            dev->tx.cpu_addr,
                            dev->tx.dma_addr);
        }
    }

    if (dev->rx.size > 0) {
        if (dev->rx.cpu_addr) {
            dma_free_coherent(&pdev->dev,
                            dev->rx.size,
                            dev->rx.cpu_addr,
                            dev->rx.dma_addr);
        }
    }


    /* destroy device nodes */
    if (dev->axidma_class) {
        device_destroy(dev->axidma_class, dev->axidma_devno + 2);
        device_destroy(dev->axidma_class, dev->axidma_devno + 1);
        device_destroy(dev->axidma_class, dev->axidma_devno);

        class_destroy(dev->axidma_class);
    }

    unregister_chrdev_region(dev->axidma_devno, 3);

    ida_free(&axidma_ida, dev->axidma_id);
    return 0;
}


static const struct of_device_id axidma_of_ids[] = {
    { .compatible = "xlnx,axi-dma-iodev-1.00.a" },
    { .compatible = "shsy,axi-dma-iodev-1.00.a" },
    { .compatible = "szsy,axi-dma-iodev-1.00.a" },
    { .compatible = "xlnx,axidma-chrdev" },
    { /* end */ }
};
MODULE_DEVICE_TABLE(of, axidma_of_ids);

static struct platform_driver axidma_drv = {
    .driver = {
        .name = DRV_MODULE_NAME,
        .of_match_table = axidma_of_ids,
    },
    .probe = axidma_probe,
    .remove = axidma_remove,
};

module_platform_driver(axidma_drv);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("szsywhf <seafly0616@qq.com>");
MODULE_DESCRIPTION("AXI DMA driver (pseudo SG, no float, kernel safe)");