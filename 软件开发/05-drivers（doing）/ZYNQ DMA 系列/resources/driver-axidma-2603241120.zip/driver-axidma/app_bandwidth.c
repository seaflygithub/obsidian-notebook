#define _GNU_SOURCE

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <ctype.h>  // 用于isdigit、tolower等函数
#include <math.h>   // 用于fabs
#include <inttypes.h> // 用于PRId64等宏

#include "axidma_common.h"

#define DEFAULT_BUFSZ (2*1024*1024UL)
static int iterations = 10;

static int h2c_fd;
static int c2h_fd;
static int ctrl_fd;

static uint8_t *tx_buf;
static uint8_t *rx_buf;
static long tx_bufsz = DEFAULT_BUFSZ;
static long rx_bufsz = DEFAULT_BUFSZ;

static uint64_t perf_results[4]; // tx(2) + rx(2)


/**
 * @brief 将字节数转换为带合适单位的字符串（B/KB/MB/GB）
 * @param bytes 输入的字节数（非负）
 * @param out_str 输出字符串缓冲区（需提前分配内存，建议长度≥32）
 * @param str_len 输出缓冲区长度
 * @return 0：转换成功，-1：参数错误
 */
int bytes_to_size_str(long long bytes, char *out_str, size_t str_len) {
    // 1. 参数合法性检查
    if (out_str == NULL || str_len < 16 || bytes < 0) {
        printf("错误：无效参数（缓冲区为空/长度不足/字节数为负）\n");
        return -1;
    }

    // 2. 处理0的特殊情况
    if (bytes == 0) {
        snprintf(out_str, str_len, "0B");
        return 0;
    }

    // 3. 定义单位数组（从大到小，便于匹配最合适的单位）
    const struct {
        long long threshold;  // 单位阈值
        const char *unit;     // 单位字符串
    } units[] = {
        {UNIT_GB, "GB"},
        {UNIT_MB, "MB"},
        {UNIT_KB, "KB"},
        {UNIT_B,  "B"}
    };
    const int unit_count = sizeof(units) / sizeof(units[0]);

    // 4. 匹配最合适的单位并计算数值
    for (int i = 0; i < unit_count; i++) {
        if (bytes >= units[i].threshold) {
            double value = (double)bytes / units[i].threshold;
            // 判断是否为整数（避免1.0KB，直接显示1KB）
            if (fabs(value - round(value)) < 1e-6) {
                // 整数格式
                snprintf(out_str, str_len, "%.0f%s", value, units[i].unit);
            } else {
                // 非整数保留1位小数（如 1500B → 1.5KB）
                snprintf(out_str, str_len, "%.1f%s", value, units[i].unit);
            }
            return 0;
        }
    }

    // 理论上不会走到这里（最后一个单位是B）
    snprintf(out_str, str_len, "%" PRId64 "B", bytes);
    return 0;
}


void buffer_dump(const char *prefix, void *buf, long bytes)
{
    // 空指针/0长度保护，避免非法访问
    if (buf == NULL || bytes <= 0) {
        printf("[%s] Invalid buffer or length\n", prefix ? prefix : "MEM");
        return;
    }

    const uint8_t *ptr = (const uint8_t *)buf;
    for (long k = 0; k < bytes; k++)
    {
        // 每行起始位置（k=0、16、32...）：先换行+打印行头
        if (k % 16 == 0)
        {
            // 第一行不额外换行（避免开头空行）
            if (k != 0) printf("\n");
            printf("[%s] %08lx: ", prefix ? prefix : "MEM", k);
        }
        // 无论是否行首，都打印当前字节（核心修正点）
        printf("%02X ", ptr[k]);
    }
    // 最后一行结束后换行，保证格式整洁
    printf("\n");
}

long long get_time_diff_us(struct timeval *start, struct timeval *end) {
    // 秒转微秒：1秒 = 1000000微秒
    long long start_us = start->tv_sec * 1000000LL + start->tv_usec;
    long long end_us = end->tv_sec * 1000000LL + end->tv_usec;
    return end_us - start_us;
}

/* ================= TX THREAD ================= */
static void *tx_thread(void *arg)
{
    long retlen;
    struct timeval t_start, t_end;
    int bufszMB;

    long total_us = 0;
    long total_bytes = 0;
    printf("%s: iterations = %d\n", __func__, iterations);
    printf("%s: tx_bufsz   = %ld\n", __func__, tx_bufsz);
    for (int i = 0; i < iterations; i++) {

        retlen = write(h2c_fd, (void *)0, tx_bufsz);
        if (retlen < 0)
        {
            printf("[%s] write failed %s\n", __func__, strerror(errno));
            break;
        }
        
    }

    pthread_exit(NULL);
    return NULL;
}

/* ================= RX THREAD ================= */
static void *rx_thread(void *arg)
{
    long retlen;
    struct timeval t_start, t_end;
    int bufszMB;
    long total_us = 0;
    long total_bytes = 0;
    printf("%s: iterations = %d\n", __func__, iterations);
    printf("%s: rx_bufsz   = %ld\n", __func__, rx_bufsz);

    for (int i = 0; i < iterations; i++) {

        gettimeofday(&t_start, NULL);

        // 该例程为什么只测RX的带宽？
        // 因为这是一次回环短接的收发测试，中间没有任何FIFO(DDR)缓冲，所以没法准确同时测收发。

        /* trigger RX DMA */
        // ioctl(ctrl_fd, AXIDMA_IOCTL_START_RX);
        retlen = read(c2h_fd, (void *)0, rx_bufsz);
        if (retlen < 0)
        {
            printf("[%s] read failed %s\n", __func__, strerror(errno));
            break;
        }

        gettimeofday(&t_end, NULL);

        total_us += get_time_diff_us(&t_start, &t_end);
        total_bytes += rx_bufsz;

        /* ===== data verify (NOT included in timing) ===== */
        for (long j=0; j<rx_bufsz; j++)
        {
            if (rx_buf[j] != (j&0xFF))
            {
                printf("data check error\n");
                // buffer_dump(__func__, &rx_buf[j-8], 128);
                return NULL;
            }
        }

        char strSize[64] = {0};
        bytes_to_size_str(rx_bufsz, strSize, sizeof(strSize));
        printf("[%4d / %-4d] bandwidth test %s SUCCESS\n", i+1, iterations, strSize);
    }


    // bandwidth formula: total*1000000000/ns/1024/1024
    double bandwidth = (double)total_bytes * 1e6 / total_us / 1024 / 1024;
    printf("============== [In App] Bandwidth Test ===============\n");
    printf("    iterations    = %d\n", iterations);
    printf("    buf_size      = %lu Bytes\n", rx_bufsz);
    printf("    total_us      = %ld\n", total_us);
    printf("    total_bytes   = %ld\n", total_bytes);
    printf("    bandwidth     = %.2lf MB/s\n", bandwidth);

    pthread_exit(NULL);
    return NULL;
}

/* ================= MAIN ================= */
int main(int argc, char **argv)
{
    char strTxSize[32] = {0};
    char strRxSize[32] = {0};
    char cmdline[512] = {0};

    // 解析命令行参数
    if (argc >= 2)
        tx_bufsz = str_to_bytes(argv[1], NULL, 0);
    if (argc >= 3)
        rx_bufsz = str_to_bytes(argv[2], NULL, 0);
    if (argc >= 4)
        iterations = atoi(argv[3]);

    bytes_to_size_str(tx_bufsz, strTxSize, sizeof(strTxSize));
    bytes_to_size_str(rx_bufsz, strRxSize, sizeof(strRxSize));

    // 这里为了测试方便, 直接在应用里调用命令安装驱动
    system("mkdir -p /lib/modules/`uname -r`");
    system("rmmod axidma_v007");
    // snprintf(cmdline, sizeof(cmdline), "insmod axidma_v007.ko tx_bufsize=6MB rx_bufsize=6MB", NULL);
    snprintf(cmdline, sizeof(cmdline), "insmod axidma_v007.ko tx_bufsize=%s rx_bufsize=%s", strTxSize, strRxSize);
    system(cmdline);
    printf("cmdline=%s\n", cmdline);

    char unit_tx[16] = {0};
    char unit_rx[16] = {0};
    bytes_to_size_str(tx_bufsz, unit_tx, sizeof(unit_tx));
    bytes_to_size_str(rx_bufsz, unit_rx, sizeof(unit_rx));
    printf("iterations  = %d\n", iterations);
    printf("tx_bufsz    = %s (%ld Bytes)\n", unit_tx, tx_bufsz);
    printf("rx_bufsz    = %s (%ld Bytes)\n", unit_rx, rx_bufsz);

    // 设备相关的初始化
    h2c_fd = open("/dev/axidma0_h2c_0", O_RDWR);
    c2h_fd = open("/dev/axidma0_c2h_0", O_RDWR);
    ctrl_fd = open("/dev/axidma0_user", O_RDWR);

    if (h2c_fd < 0 || c2h_fd < 0 || ctrl_fd < 0) {
        perror("open");
        printf("h2c_fd=%d, c2h_fd=%d, ctrl_fd=%d\n", h2c_fd, c2h_fd, ctrl_fd);
        return -1;
    }

    /* ================= 内存相关的初始化 ================= */
    tx_buf = mmap(NULL, tx_bufsz, PROT_READ | PROT_WRITE, MAP_SHARED, h2c_fd, 0);
    rx_buf = mmap(NULL, rx_bufsz, PROT_READ | PROT_WRITE, MAP_SHARED, c2h_fd, 0);
    if (tx_buf == MAP_FAILED || rx_buf == MAP_FAILED) {
        perror("mmap");
        return -1;
    }
    // init tx data
    memset(tx_buf, 0, tx_bufsz);
    for(long i=0; i<tx_bufsz; i++)
    {
        tx_buf[i] = (uint8_t)i;
    }
    // buffer_dump(__func__, tx_buf, 128);
    printf("mmap success: tx=%p rx=%p\n", tx_buf, rx_buf);

    
    // 开始收发之前, 开启驱动层的性能计数
    // ioctl(ctrl_fd, AXIDMA_IOCTL_PERF_BEGIN, 0);

    pthread_t tx, rx;
    pthread_create(&tx, NULL, tx_thread, NULL);
    pthread_create(&rx, NULL, rx_thread, NULL);
    pthread_join(tx, NULL);
    pthread_join(rx, NULL);

    // 收发测试结束后, 统计驱动层的性能计数
    // ioctl(ctrl_fd, AXIDMA_IOCTL_PERF_END, &perf_results);
    // uint64_t total, ns;
    // perf_results[0]; // tx_total_ns;
    // perf_results[1]; // rx_total_ns;
    // perf_results[2]; // tx_total_bytes;
    // perf_results[3]; // rx_total_bytes;
    // total = perf_results[3];
    // ns = perf_results[1];

    // 驱动层也计算带宽，用于对比和应用层的差距
    // printf("============== [In Driver] Bandwidth Test ===============\n");
    // printf("    total_ns      = %llu\n", ns);
    // printf("    total_bytes   = %llu\n", total);
    // printf("    bandwidth     = %.2lf MBps\n", 
    // (double)total*1000000000/ns/1024/1024);

    munmap(tx_buf, tx_bufsz);
    munmap(rx_buf, rx_bufsz);

    close(h2c_fd);
    close(c2h_fd);
    close(ctrl_fd);

    return 0;
}