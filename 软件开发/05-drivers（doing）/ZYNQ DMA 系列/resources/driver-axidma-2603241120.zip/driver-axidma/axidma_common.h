#ifndef _AXIDMA_COMMON_H
#define _AXIDMA_COMMON_H

#define AXIDMA_IOCTL_PERF_BEGIN 26032120
#define AXIDMA_IOCTL_PERF_END   26032121


// 定义单位换算系数（字节）
#define UNIT_B  (1LL)
#define UNIT_KB (1024LL)
#define UNIT_MB (1024LL * 1024LL)
#define UNIT_GB (1024LL * 1024LL * 1024LL)
#ifndef LLONG_MIN
#define LLONG_MIN 0x8000000000000000LL
#define LLONG_MAX 0x7FFFFFFFFFFFFFFFLL
#endif // LLONG_MIN

/**
 * @brief 自定义实现atoll功能：字符串转long long整数,没有负数路径
 * @param str 输入字符串（支持正负号、前导空白，如"  -123456789012345"）
 * @return 转换后的long long值；溢出时返回LLONG_MAX/LLONG_MIN，空字符串/无数字返回0
 * @note 行为对齐标准atoll：
 *       1. 跳过前导空白字符（空格、制表符、换行等）
 *       2. 支持可选的正负号（+/-）
 *       3. 遇到第一个非数字字符停止转换
 *       4. 溢出时返回LLONG_MAX（正数）/LLONG_MIN（负数）
 */
static long long my_atoll(const char *str)
{
    if (!str)
        return 0;

    unsigned long long result = 0;

    /* 跳过空白 */
    while (*str == ' ' || *str == '\t' || *str == '\n' ||
           *str == '\r' || *str == '\f' || *str == '\v') {
        str++;
    }

    /* 可选 + 号 */
    if (*str == '+')
        str++;

    while (*str >= '0' && *str <= '9') {
        unsigned int digit = *str - '0';

        /* 溢出判断（无除法版本） */
        if (result > 922337203685477580ULL ||
           (result == 922337203685477580ULL && digit > 7)) {
            return LLONG_MAX;
        }

        result = result * 10 + digit;
        str++;
    }

    return (long long)result;
}


// "1024B",    // 1024
// "32MB",     // 32*1024*1024 = 33554432
// "2GB",      // 2*1024*1024*1024 = 2147483648
// "512kb",    // 大小写兼容，512*1024=524288
// "100",      // 无单位默认B，100
// "1024GB",   // 溢出测试
// "abcMB",    // 非法数字
// "512XB",    // 非法单位
/**
 * @brief 解析带单位的存储大小字符串为字节数
 * @param str 输入字符串（如"1024B"、"32MB"、"2GB"）
 * @param errstr 存放错误信息,如果传入NULL,则caller不想要错误信息
 * @return 成功返回字节数,失败返回负数
 */
static long long str_to_bytes(const char *str, char errstr[256], int errstrsz) {

    int ret;
    long long num;
    char *end_ptr = NULL;
    char unit[8] = {0};  // 存储单位（B/KB/MB/GB）
    int i,j;
    int i_unit;
    long long multiplier = UNIT_B;
    char strSzA[32] = {0}; // 存放数字字符串
    char strSzB[8] = {0}; // 存放单位字符串
    char slen = strlen(str);
    memset(errstr, 0, errstrsz);

    if (str == NULL || *str == '\0') {
        // printf("Invalid empty string\n");
        if (errstr)
        {
            snprintf(errstr, errstrsz, "%s", "Invalid empty string");
        }
        return -EINVAL;
    }

    // (1) str="2MB" 拆成 "2" "MB"
    // (2) 把单位全部转换成小写, 如果没有单位, 默认为B

    for (i=0,j=0; i<slen; i++)
    {
        if ( !isdigit(str[i]) )
        {
            i_unit = i; // 单位字符起始
            break;
        }

        // 如果是数字, 存放到A数组
        strSzA[j] = str[i];
        j += 1;
    }
    num = my_atoll(strSzA);
    // ret = kstrtoll(strSzA, 10, &num);
    // if (ret < 0)
    // {
    //     printf("invalid digit string\n");
    //     return -EINVAL;
    // }

    // 拿到单位字符串，并转换成小写
    for (i=i_unit,j=0; str[i] != '\0'; i++)
    {
        strSzB[j] = tolower(str[i]);
        unit[j] = strSzB[j];
        j += 1;
    }

    if (strnlen(unit, sizeof(unit)) == 0)
    {
        multiplier = UNIT_B;
    }
    else if (strcmp(unit, "b") == 0 || *unit == '\0') {
        multiplier = UNIT_B;
    } else if (strcmp(unit, "kb") == 0) {
        multiplier = UNIT_KB;
    } else if (strcmp(unit, "mb") == 0) {
        multiplier = UNIT_MB;
    } else if (strcmp(unit, "gb") == 0) {
        multiplier = UNIT_GB;
    } else {
        // printf("Unsupported unit: %s\n", unit);
        if (errstr)
        {
            snprintf(errstr, errstrsz, "Unsupported unit: %s", unit);
        }
        return -EINVAL;
    }

    return num * multiplier;
}

#endif // _AXIDMA_COMMON_H