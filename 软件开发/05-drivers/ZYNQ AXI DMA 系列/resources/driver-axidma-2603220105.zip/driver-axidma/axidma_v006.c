﻿#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/stat.h>
#include <linux/platform_device.h>
#include <linux/device.h>
#include <linux/dmaengine.h>
#include <linux/errno.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/dma-mapping.h>
#include <linux/completion.h>
#include <linux/jiffies.h>
#include <linux/ktime.h>
#include <linux/random.h>
#include <linux/scatterlist.h>

#define DRV_MODULE_NAME "axidma"

#define MAX_SEG_SIZE (1*1024*1024)
#define TEST_BUF_SIZE        (2*1024*1024)
#define TEST_ITERATIONS      10
#define DMA_TIMEOUT_MS       5000

struct szsywhf_axidma_device {
    struct platform_device *pdev;
    struct dma_chan *tx_chan, *rx_chan;

    dma_addr_t tx_dma_addr;
    dma_addr_t rx_dma_addr;
    void *tx_buf;
    void *rx_buf;
    size_t buf_size;

    struct completion tx_cmp;
    struct completion rx_cmp;

    u64 total_ns;
    u64 total_bytes;
};

static int test_iterations = TEST_ITERATIONS;
static int test_buf_size = TEST_BUF_SIZE;
static int test_seg_size = MAX_SEG_SIZE;

// 传输方式选择
static char txmethod[64] = "sg"; // "single", "multi-single", "sg"

module_param(test_iterations, int, 0444);
module_param(test_buf_size, int, 0444);
module_param(test_seg_size, int, 0444);
module_param_string(txmethod, txmethod, 64, 0644);
MODULE_PARM_DESC(txmethod, "txmethod list: single, multi-single, sg");

static void tx_cb(void *param)
{
    complete(param);
}

static void rx_cb(void *param)
{
    complete(param);
}

static int verify_data(const u8 *tx, const u8 *rx, size_t len)
{
    size_t i;
    for (i = 0; i < len; i++) {
        if (tx[i] != rx[i]) {
            pr_err("mismatch at %zu: tx=0x%02x rx=0x%02x\n", i, tx[i], rx[i]);
            return -EINVAL;
        }
    }
    return 0;
}

static void fill_buf(u8 *buf, size_t len)
{
    size_t i;
    for (i = 0; i < len; i++)
        buf[i] = (i & 0xFF);
}


static int do_sg_test(struct szsywhf_axidma_device *dev)
{
    struct dma_async_tx_descriptor *txd = NULL, *rxd = NULL;
    struct scatterlist *tx_sg_ptr = NULL, *rx_sg_ptr = NULL;
    struct scatterlist *sg;

    size_t max_seg_size = test_seg_size;
    size_t remaining_len;

    dma_addr_t curr_tx_addr, curr_rx_addr;

    int tx_segs = 0;
    int rx_segs = 0;

    int ret = 0;

    /* 初始化 completion */
    reinit_completion(&dev->tx_cmp);
    reinit_completion(&dev->rx_cmp);

    /* 计算 SG 段数 */
    tx_segs = DIV_ROUND_UP(dev->buf_size, max_seg_size);
    rx_segs = tx_segs;

    pr_info("SG split: %zu bytes -> %d segments (seg_size=%zu)\n",
            dev->buf_size, tx_segs, max_seg_size);

    /* 分配 SG 表 */
    tx_sg_ptr = kcalloc(tx_segs, sizeof(struct scatterlist), GFP_KERNEL);
    rx_sg_ptr = kcalloc(rx_segs, sizeof(struct scatterlist), GFP_KERNEL);

    if (!tx_sg_ptr || !rx_sg_ptr) {
        pr_err("Failed to allocate SG table\n");
        ret = -ENOMEM;
        goto free_sg;
    }

    sg_init_table(tx_sg_ptr, tx_segs);
    sg_init_table(rx_sg_ptr, rx_segs);

    /* ========================= */
    /* 构建 TX SG list */
    /* ========================= */

    curr_tx_addr = dev->tx_dma_addr;
    remaining_len = dev->buf_size;

    for (sg = tx_sg_ptr; remaining_len > 0; sg = sg_next(sg)) {

        size_t seg_len = min(remaining_len, max_seg_size);

        sg_dma_address(sg) = curr_tx_addr;
        sg_dma_len(sg) = seg_len;

        curr_tx_addr += seg_len;
        remaining_len -= seg_len;
    }

    /* ========================= */
    /* 构建 RX SG list */
    /* ========================= */

    curr_rx_addr = dev->rx_dma_addr;
    remaining_len = dev->buf_size;

    for (sg = rx_sg_ptr; remaining_len > 0; sg = sg_next(sg)) {

        size_t seg_len = min(remaining_len, max_seg_size);

        sg_dma_address(sg) = curr_rx_addr;
        sg_dma_len(sg) = seg_len;

        pr_debug("RX SG: addr=0x%llx len=%zu\n",
                 (unsigned long long)sg_dma_address(sg),
                 sg_dma_len(sg));

        curr_rx_addr += seg_len;
        remaining_len -= seg_len;
    }

    /* ========================= */
    /* 准备 RX DMA */
    /* ========================= */

    rxd = dmaengine_prep_slave_sg(dev->rx_chan,
                                  rx_sg_ptr,
                                  rx_segs,
                                  DMA_DEV_TO_MEM,
                                  DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!rxd) {
        pr_err("RX SG prep failed\n");
        ret = -ENOMEM;
        goto free_sg;
    }

    rxd->callback = rx_cb;
    rxd->callback_param = &dev->rx_cmp;

    dmaengine_submit(rxd);

    /* ========================= */
    /* 准备 TX DMA */
    /* ========================= */

    txd = dmaengine_prep_slave_sg(dev->tx_chan,
                                  tx_sg_ptr,
                                  tx_segs,
                                  DMA_MEM_TO_DEV,
                                  DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!txd) {
        pr_err("TX SG prep failed\n");
        dmaengine_terminate_all(dev->rx_chan);
        ret = -ENOMEM;
        goto free_sg;
    }

    txd->callback = tx_cb;
    txd->callback_param = &dev->tx_cmp;

    dmaengine_submit(txd);

    /* ========================= */
    /* 启动 DMA */
    /* ========================= */

    dma_async_issue_pending(dev->rx_chan);
    dma_async_issue_pending(dev->tx_chan);

    /* ========================= */
    /* 等待 TX 完成 */
    /* ========================= */

    if (!wait_for_completion_timeout(&dev->tx_cmp,
                                     msecs_to_jiffies(DMA_TIMEOUT_MS))) {

        pr_err("TX SG DMA timeout (%d segments)\n", tx_segs);

        dmaengine_terminate_all(dev->tx_chan);
        dmaengine_terminate_all(dev->rx_chan);

        ret = -ETIMEDOUT;
        goto free_sg;
    }

    /* ========================= */
    /* 等待 RX 完成 */
    /* ========================= */

    if (!wait_for_completion_timeout(&dev->rx_cmp,
                                     msecs_to_jiffies(DMA_TIMEOUT_MS))) {

        pr_err("RX SG DMA timeout (%d segments)\n", rx_segs);

        dmaengine_terminate_all(dev->rx_chan);
        dmaengine_terminate_all(dev->tx_chan);

        ret = -ETIMEDOUT;
        goto free_sg;
    }

free_sg:

    kfree(tx_sg_ptr);
    kfree(rx_sg_ptr);

    return ret;
}


static int do_multi_single_test(struct szsywhf_axidma_device *dev)
{
    struct dma_async_tx_descriptor *txd, *rxd;
    // struct dma_slave_caps caps;
    size_t max_seg_size;
    size_t remaining_len;
    dma_addr_t curr_tx_addr, curr_rx_addr;
    int ret = 0;

    // 初始化完成量
    reinit_completion(&dev->tx_cmp);
    reinit_completion(&dev->rx_cmp);

    // 获取硬件最大单段长度
    max_seg_size = test_seg_size;
    pr_info("Use single segment transfer, max size: %zu bytes\n", max_seg_size);

    // 循环单段传输（替代SG）
    curr_tx_addr = dev->tx_dma_addr;
    curr_rx_addr = dev->rx_dma_addr;
    remaining_len = dev->buf_size;

    while (remaining_len > 0 && ret == 0) {
        size_t seg_len = min(remaining_len, max_seg_size);

        // 准备RX单段传输
        rxd = dmaengine_prep_slave_single(dev->rx_chan, curr_rx_addr,
                                           seg_len, DMA_DEV_TO_MEM,
                                           DMA_PREP_INTERRUPT | DMA_CTRL_ACK);
        if (!rxd) {
            pr_err("RX single prep failed, len: %zu\n", seg_len);
            ret = -ENOMEM;
            break;
        }
        rxd->callback = rx_cb;
        rxd->callback_param = &dev->rx_cmp;
        dmaengine_submit(rxd);

        // 准备TX单段传输
        txd = dmaengine_prep_slave_single(dev->tx_chan, curr_tx_addr,
                                           seg_len, DMA_MEM_TO_DEV,
                                           DMA_PREP_INTERRUPT | DMA_CTRL_ACK);
        if (!txd) {
            pr_err("TX single prep failed, len: %zu\n", seg_len);
            dmaengine_terminate_all(dev->rx_chan);
            ret = -ENOMEM;
            break;
        }
        txd->callback = tx_cb;
        txd->callback_param = &dev->tx_cmp;
        dmaengine_submit(txd);

        // 启动传输
        dma_async_issue_pending(dev->rx_chan);
        dma_async_issue_pending(dev->tx_chan);

        // 等待RX完成
        if (!wait_for_completion_timeout(&dev->rx_cmp, msecs_to_jiffies(DMA_TIMEOUT_MS))) {
            pr_err("RX timeout, len: %zu\n", seg_len);
            dmaengine_terminate_all(dev->rx_chan);
            dmaengine_terminate_all(dev->tx_chan);
            ret = -ETIMEDOUT;
            break;
        }

        // 等待TX完成
        if (!wait_for_completion_timeout(&dev->tx_cmp, msecs_to_jiffies(DMA_TIMEOUT_MS))) {
            pr_err("TX timeout, len: %zu\n", seg_len);
            dmaengine_terminate_all(dev->tx_chan);
            ret = -ETIMEDOUT;
            break;
        }

        // 更新地址和剩余长度
        curr_tx_addr += seg_len;
        curr_rx_addr += seg_len;
        remaining_len -= seg_len;
        pr_debug("Transferred %zu bytes, remaining: %zu\n", seg_len, remaining_len);

        // 重置完成量，准备下一段
        reinit_completion(&dev->tx_cmp);
        reinit_completion(&dev->rx_cmp);
    }

    return ret;
}

static int do_single_test(struct szsywhf_axidma_device *dev)
{
    struct dma_async_tx_descriptor *txd, *rxd;

    // int ret;
    // ktime_t t_start, t_end;
    // u64 ns;

    reinit_completion(&dev->tx_cmp);
    reinit_completion(&dev->rx_cmp);

    // fill_buf(dev->tx_buf, dev->buf_size);
    // memset(dev->rx_buf, 0, dev->buf_size);

    // 先提交 RX
    rxd = dmaengine_prep_slave_single(dev->rx_chan, dev->rx_dma_addr,
                                       dev->buf_size, DMA_DEV_TO_MEM,
                                       DMA_PREP_INTERRUPT | DMA_CTRL_ACK);
    if (!rxd) return -ENOMEM;
    // pr_info("buf_size = %ld\n", dev->buf_size);

    rxd->callback = rx_cb;
    rxd->callback_param = &dev->rx_cmp;
    dmaengine_submit(rxd);

    // 再提交 TX
    txd = dmaengine_prep_slave_single(dev->tx_chan, dev->tx_dma_addr,
                                       dev->buf_size, DMA_MEM_TO_DEV,
                                       DMA_PREP_INTERRUPT | DMA_CTRL_ACK);
    if (!txd) return -ENOMEM;

    txd->callback = tx_cb;
    txd->callback_param = &dev->tx_cmp;
    dmaengine_submit(txd);

    // 计时开始
    // t_start = ktime_get();
    dma_async_issue_pending(dev->rx_chan);
    dma_async_issue_pending(dev->tx_chan);

    if (!wait_for_completion_timeout(&dev->rx_cmp, msecs_to_jiffies(DMA_TIMEOUT_MS))) {
        pr_err("rx timeout\n");
        dmaengine_terminate_all(dev->rx_chan);
        return -ETIMEDOUT;
    }

    if (!wait_for_completion_timeout(&dev->tx_cmp, msecs_to_jiffies(DMA_TIMEOUT_MS))) {
        pr_err("tx timeout\n");
        dmaengine_terminate_all(dev->tx_chan);
        return -ETIMEDOUT;
    }

    // // 计时结束
    // t_end = ktime_get();
    // ns = ktime_to_ns(ktime_sub(t_end, t_start));
    // dev->total_ns += ns;
    // dev->total_bytes += dev->buf_size;

    // ret = verify_data(dev->tx_buf, dev->rx_buf, dev->buf_size);
    // if (ret)
    //     return ret;

    return 0;
}

static int run_all_tests(struct szsywhf_axidma_device *dev)
{
    int i, ret;
	
	// 函数指针,根据用户参数选择指定传输方式
	int (*do_test_method)(struct szsywhf_axidma_device *dev);

    ktime_t t_start, t_end;
    u64 ns;
	
	
	if (strncmp(txmethod, "sg", 2)==0)
	{
		do_test_method = do_sg_test;
	} else if (strncmp(txmethod, "multi-single", 12)==0)
	{
		do_test_method = do_multi_single_test;
	} else 
	{
		do_test_method = do_single_test;
	}
	

    dev->total_ns = 0;
    dev->total_bytes = 0;
    dev->buf_size = test_buf_size;

    // 每次传输 1MB
    pr_info("start test: %d iterations, %zu bytes\n", test_iterations, dev->buf_size);

    dev->total_ns = 0;
    dev->total_bytes = 0;

    // 总共传输 10 次
    for (i = 0; i < test_iterations; i++) {

        // 每次传输 1 MB
        fill_buf(dev->tx_buf, dev->buf_size);
        memset(dev->rx_buf, 0, dev->buf_size);
        // printk("dev->buf_size = %ld\n", dev->buf_size);

        // 计时开始
        t_start = ktime_get();
        // ret = do_single_test(dev);
        // ret = do_sg_test(dev);
		ret = do_test_method(dev);
        if (ret) {
            pr_err("test %d failed\n", i);
            return ret;
        }

        // 计时结束
        t_end = ktime_get();
        ns = ktime_to_ns(ktime_sub(t_end, t_start));
        dev->total_ns += ns;
        dev->total_bytes += dev->buf_size;

        ret = verify_data(dev->tx_buf, dev->rx_buf, dev->buf_size);
        if (ret)
            return ret;
        
        pr_info("dev->buf_size=%d KB, test_seg_size=%d KB, test %d ok\n", 
            dev->buf_size/1024, test_seg_size/1024, i);
    }

    if (dev->total_ns > 0) {
        u64 total_bytes = dev->total_bytes;
        u64 total_ns = dev->total_ns;

        // 下面是总耗时,内核空间不支持浮点型,所以拿到下面数据后手动计算带宽
        // 手动计算带宽公式: xBytesPS/1000000000 = total_bytes/total_ns
        // 公式中,其中 xBytesPS 就是带宽 (单位: Bytes/sec)
        pr_info("[TEST] total_bytes is %llu\n", total_bytes);
        pr_info("[TEST] total_ns is %llu\n", total_ns);
    }

    return 0;
}

static int axidma_probe(struct platform_device *pdev)
{
	int i;
    struct szsywhf_axidma_device *dev;
    int ret;
    pr_info("called %s\n", __func__);

    dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
    if (!dev) return -ENOMEM;

    dev->pdev = pdev;
    init_completion(&dev->tx_cmp);
    init_completion(&dev->rx_cmp);

    dev->tx_chan = dma_request_chan(&pdev->dev, "tx_channel");
    if (IS_ERR(dev->tx_chan)) {
        ret = PTR_ERR(dev->tx_chan);
        pr_err("get tx chan fail\n");
        return ret;
    }

    dev->rx_chan = dma_request_chan(&pdev->dev, "rx_channel");
    if (IS_ERR(dev->rx_chan)) {
        ret = PTR_ERR(dev->rx_chan);
        pr_err("get rx chan fail\n");
        dma_release_channel(dev->tx_chan);
        return ret;
    }

    dev->tx_buf = dma_alloc_coherent(&pdev->dev, test_buf_size,
                                     &dev->tx_dma_addr, GFP_KERNEL);
    if (!dev->tx_buf) {
        ret = -ENOMEM;
        goto err_rx;
    }

    dev->rx_buf = dma_alloc_coherent(&pdev->dev, test_buf_size,
                                     &dev->rx_dma_addr, GFP_KERNEL);
    if (!dev->rx_buf) {
        ret = -ENOMEM;
        goto err_txbuf;
    }

    platform_set_drvdata(pdev, dev);
	
	
	pr_info("txmethod        = %s (list: sg, single, multi-single)\n", txmethod);
	pr_info("test_iterations = %d\n", test_iterations);
	pr_info("test_buf_size   = %d KB\n", test_buf_size/1024);
	pr_info("test_seg_size   = %d KB (for sg and multi-single)\n\n", test_seg_size/1024);
	
	do {
		ret = run_all_tests(dev);
		if (ret)
		{
			pr_warn("test failed\n");
			break;
		}
	} while(0);

    return 0;

err_txbuf:
    dma_free_coherent(&pdev->dev, test_buf_size, dev->tx_buf, dev->tx_dma_addr);
err_rx:
    dma_release_channel(dev->rx_chan);
    dma_release_channel(dev->tx_chan);
    return ret;
}

static int axidma_remove(struct platform_device *pdev)
{
    struct szsywhf_axidma_device *dev = platform_get_drvdata(pdev);

    dmaengine_terminate_all(dev->tx_chan);
    dmaengine_terminate_all(dev->rx_chan);

    dma_release_channel(dev->tx_chan);
    dma_release_channel(dev->rx_chan);

    dma_free_coherent(&pdev->dev, test_buf_size, dev->tx_buf, dev->tx_dma_addr);
    dma_free_coherent(&pdev->dev, test_buf_size, dev->rx_buf, dev->rx_dma_addr);

    pr_info("called %s\n", __func__);
    return 0;
}

static const struct of_device_id axidma_of_ids[] = {
    { .compatible = "xlnx,axi-dma-iodev-1.00.a" },
    { .compatible = "shsy,axi-dma-iodev-1.00.a" },
    { .compatible = "szsy,axi-dma-iodev-1.00.a" },
    { .compatible = "xlnx,axidma-chrdev" },
    { /* end */ }
};
MODULE_DEVICE_TABLE(of, axidma_of_ids);

static struct platform_driver axidma_drv = {
    .driver = {
        .name = DRV_MODULE_NAME,
        .of_match_table = axidma_of_ids,
    },
    .probe = axidma_probe,
    .remove = axidma_remove,
};

module_platform_driver(axidma_drv);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("szsywhf <seafly0616@qq.com>");
MODULE_DESCRIPTION("AXI DMA driver (pseudo SG, no float, kernel safe)");