#!/bin/bash

# Usage:
#source /xilinx_sdk_settings64.sh
# source /home/vitis_settings64.sh
source /home/xsdk_2018.3_settings64.sh

export ARCH=arm
export CROSS_COMPILE=arm-linux-gnueabihf-
export KDIR=`pwd`/..
#make KDIR=`pwd`/../linux-xlnx-master
make clean
make && mv -v *.ko ../ && make clean && mv -v ../*.ko ./

#app_src=./app_axidma.c
#app_bin=./app_axidma.elf
#arm-linux-gnueabihf-gcc -static $app_src -o $app_bin -I./ -lpthread

