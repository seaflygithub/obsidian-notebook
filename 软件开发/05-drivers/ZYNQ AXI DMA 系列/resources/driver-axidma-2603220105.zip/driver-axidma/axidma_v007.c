﻿#include "axidma_common.h"

#include <linux/module.h>
#include <linux/init.h>

#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_device.h>

#include <linux/dmaengine.h>
#include <linux/dma-mapping.h>

#include <linux/completion.h>
#include <linux/slab.h>
#include <linux/gfp.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>

#include <linux/uaccess.h>

#include <linux/scatterlist.h>

#include <linux/errno.h>
#include <linux/err.h>

#include <linux/jiffies.h>
#include <linux/time.h>

#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/types.h>

#include <linux/printk.h>


// #include <linux/delay.h>
// #include <linux/wait.h>
// #include <linux/module.h>
// #include <linux/moduleparam.h>
// #include <linux/slab.h>
// #include <linux/stat.h>
// #include <linux/platform_device.h>
// #include <linux/device.h>
// #include <linux/dmaengine.h>
// #include <linux/errno.h>
// #include <linux/of.h>
// #include <linux/of_device.h>
// #include <linux/dma-mapping.h>
// #include <linux/completion.h>
// #include <linux/jiffies.h>
// #include <linux/ktime.h>
// #include <linux/random.h>
// #include <linux/scatterlist.h>

// // =========== 用户空间buf处理 ===============
// #include <linux/mm.h>
// #include <linux/highmem.h>

#define DRV_MODULE_NAME "axidma"

#define MAX_SEG_SIZE (1*1024*1024)
#define TEST_BUF_SIZE        (2*1024*1024)
#define TEST_ITERATIONS      10
#define DMA_TIMEOUT_MS       5000

struct axidma_buf {
    void *cpu_addr;
    dma_addr_t dma_addr;
    size_t size;
};

struct szsywhf_axidma_device {
    struct platform_device *pdev;

    struct dma_chan *tx_chan;
    struct dma_chan *rx_chan;

    struct axidma_buf tx;
    struct axidma_buf rx;

    struct completion tx_cmp;
    struct completion rx_cmp;

    // 用来协助带宽测试
    u64 tx_total_ns;// unit: nano second
    u64 rx_total_ns;// unit: nano second
    u64 tx_total_bytes;
    u64 rx_total_bytes;
    

    /* 3个设备节点 */
    // dev_t devt_ctrl;
    // dev_t devt_h2c;
    // dev_t devt_c2h;

    // struct cdev cdev_ctrl;
    // struct cdev cdev_h2c;
    // struct cdev cdev_c2h;
    struct cdev cdev_ctrl;
    struct cdev cdev_h2c;
    struct cdev cdev_c2h;
    dev_t devt_ctrl;


    struct class *class;
};

static int test_iterations = TEST_ITERATIONS;
static int test_buf_size = TEST_BUF_SIZE;
static int test_seg_size = MAX_SEG_SIZE;

// 传输方式选择
static char txmethod[64] = "sg"; // "single", "multi-single", "sg"

module_param(test_iterations, int, 0444);
module_param(test_buf_size, int, 0444);
module_param(test_seg_size, int, 0444);
module_param_string(txmethod, txmethod, 64, 0644);
MODULE_PARM_DESC(txmethod, "txmethod list: single, multi-single, sg");

static void tx_cb(void *param)
{
    complete(param);
}

static void rx_cb(void *param)
{
    complete(param);
}

static int verify_data(const u8 *tx, const u8 *rx, size_t len)
{
    size_t i;
    for (i = 0; i < len; i++) {
        if (tx[i] != rx[i]) {
            pr_err("mismatch at %zu: tx=0x%02x rx=0x%02x\n", i, tx[i], rx[i]);
            return -EINVAL;
        }
    }
    return 0;
}

static void fill_buf(u8 *buf, size_t len)
{
    size_t i;
    for (i = 0; i < len; i++)
        buf[i] = (i & 0xFF);
}


static int axidma_h2c_mmap(struct file *file,
                           struct vm_area_struct *vma)
{
    struct szsywhf_axidma_device *dev = file->private_data;

    return dma_mmap_coherent(&dev->pdev->dev,
                             vma,
                             dev->tx.cpu_addr,
                             dev->tx.dma_addr,
                             dev->tx.size);
}

static int axidma_c2h_mmap(struct file *file,
                           struct vm_area_struct *vma)
{
    struct szsywhf_axidma_device *dev = file->private_data;

    return dma_mmap_coherent(&dev->pdev->dev,
                             vma,
                             dev->rx.cpu_addr,
                             dev->rx.dma_addr,
                             dev->rx.size);
}


static int start_tx_dma(struct szsywhf_axidma_device *dev)
{
    struct dma_async_tx_descriptor *txd;

    reinit_completion(&dev->tx_cmp);

    txd = dmaengine_prep_slave_single(
        dev->tx_chan,
        dev->tx.dma_addr,
        dev->tx.size,
        DMA_MEM_TO_DEV,
        DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!txd)
        return -ENOMEM;

    txd->callback = tx_cb;
    txd->callback_param = &dev->tx_cmp;

    dmaengine_submit(txd);
    dma_async_issue_pending(dev->tx_chan);

    // wait_for_completion_timeout(&dev->tx_cmp, msecs_to_jiffies(30000));
    wait_for_completion_interruptible_timeout(&dev->tx_cmp, msecs_to_jiffies(30000));

    return 0;
}

static int start_rx_dma(struct szsywhf_axidma_device *dev)
{
    struct dma_async_tx_descriptor *rxd;

    reinit_completion(&dev->rx_cmp);

    rxd = dmaengine_prep_slave_single(
        dev->rx_chan,
        dev->rx.dma_addr,
        dev->rx.size,
        DMA_DEV_TO_MEM,
        DMA_PREP_INTERRUPT | DMA_CTRL_ACK);

    if (!rxd)
        return -ENOMEM;

    rxd->callback = rx_cb;
    rxd->callback_param = &dev->rx_cmp;

    dmaengine_submit(rxd);
    dma_async_issue_pending(dev->rx_chan);

    // wait_for_completion_timeout(&dev->rx_cmp, msecs_to_jiffies(30000));
    wait_for_completion_interruptible_timeout(&dev->rx_cmp, msecs_to_jiffies(30000));
    
    return 0;
}

static ssize_t axidma_h2c_write(struct file *file,
                         const char __user *buf,
                         size_t len,
                         loff_t *off)
{
    ktime_t t_start, t_end;
    u64 ns;

    ssize_t retlen;
    struct szsywhf_axidma_device *dev = file->private_data;
    dev->tx.size = len;

    t_start = ktime_get();

    retlen = start_tx_dma(dev);
    if (retlen == 0)
        retlen = len;

    t_end = ktime_get();
    ns = ktime_to_ns(ktime_sub(t_end, t_start));
    dev->tx_total_ns += ns;
    dev->tx_total_bytes += (retlen>0? retlen:0);

    return retlen;
}

static ssize_t axidma_c2h_read(struct file *file,
                        char __user *buf,
                        size_t len,
                        loff_t *off)
{
    ktime_t t_start, t_end;
    u64 ns;

    ssize_t retlen;
    struct szsywhf_axidma_device *dev = file->private_data;
    dev->rx.size = len;

    t_start = ktime_get();

    retlen = start_rx_dma(dev);
    if (retlen == 0)
        retlen = len;

    t_end = ktime_get();
    ns = ktime_to_ns(ktime_sub(t_end, t_start));
    dev->rx_total_ns += ns;
    dev->rx_total_bytes += (retlen>0? retlen:0);

    return retlen;
}


static long axidma_ioctl(struct file *file,
                         unsigned int cmd,
                         unsigned long arg)
{
    int ret;
    u64 perf_results[4]; // tx(2) + rx(2)
    struct szsywhf_axidma_device *dev = file->private_data;

    switch (cmd) {

    case AXIDMA_IOCTL_PERF_BEGIN:
    {
        dev->tx_total_ns = 0;
        dev->rx_total_ns = 0;
        dev->tx_total_bytes = 0;
        dev->rx_total_bytes = 0;
        return 0;
    }

    case AXIDMA_IOCTL_PERF_END:
    {
        perf_results[0] = dev->tx_total_ns;
        perf_results[1] = dev->rx_total_ns;
        perf_results[2] = dev->tx_total_bytes;
        perf_results[3] = dev->rx_total_bytes;

        ret = copy_to_user((long __user *)arg, 
                perf_results, sizeof(perf_results));
        return ret;
    }

    default:
        return -EINVAL;
    }
}

static int axidma_open_ctrl(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_ctrl);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static int axidma_h2c_open(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_h2c);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static int axidma_c2h_open(struct inode *inode, struct file *file)
{
    struct szsywhf_axidma_device *dev;

    dev = container_of(inode->i_cdev,
                       struct szsywhf_axidma_device,
                       cdev_c2h);

    if (!dev)
        return -ENODEV;

    file->private_data = dev;

    return 0;
}

static ssize_t reg_read(struct file *file,
                        char __user *buf,
                        size_t len,
                        loff_t *off)
{
    struct szsywhf_axidma_device *dev = file->private_data;
    // u32 value;
    // size_t reg_idx;

    // if (*off % 4 != 0)
    //     return -EINVAL;

    // reg_idx = *off / 4;

    // if (reg_idx >= 256)
    //     return -EINVAL;

    // value = dev->regs[reg_idx];

    // if (len > sizeof(u32))
    //     len = sizeof(u32);

    // if (copy_to_user(buf, &value, len))
    //     return -EFAULT;

    // *off += len;

    return len;
}

static ssize_t reg_write(struct file *file,
                         const char __user *buf,
                         size_t len,
                         loff_t *off)
{
    struct szsywhf_axidma_device *dev = file->private_data;
    // u32 value;
    // size_t reg_idx;

    // if (*off % 4 != 0)
    //     return -EINVAL;

    // reg_idx = *off / 4;

    // if (reg_idx >= 256)
    //     return -EINVAL;

    // if (len > sizeof(u32))
    //     len = sizeof(u32);

    // if (copy_from_user(&value, buf, len))
    //     return -EFAULT;

    // dev->regs[reg_idx] = value;

    // pr_debug("reg_write: [%zu] = 0x%x\n", reg_idx, value);

    // *off += len;

    return len;
}


static const struct file_operations h2c_fops = {
    .owner = THIS_MODULE,
    .mmap  = axidma_h2c_mmap,
    .open  = axidma_h2c_open,
    .write = axidma_h2c_write,
};

static const struct file_operations c2h_fops = {
    .owner = THIS_MODULE,
    .mmap  = axidma_c2h_mmap,
    .open  = axidma_c2h_open,
    .read  = axidma_c2h_read,
};

static const struct file_operations ctrl_fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = axidma_ioctl,
    .read           = reg_read,
    .write          = reg_write,
    .open           = axidma_open_ctrl,
};

static int axidma_probe(struct platform_device *pdev)
{
    struct szsywhf_axidma_device *dev;
    int ret;

    pr_info("called %s\n", __func__);

    dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
    if (!dev)
        return -ENOMEM;

    dev->pdev = pdev;
    platform_set_drvdata(pdev, dev);

    init_completion(&dev->tx_cmp);
    init_completion(&dev->rx_cmp);

    /* ================= DMA channels ================= */
    dev->tx_chan = dma_request_chan(&pdev->dev, "tx_channel");
    if (IS_ERR(dev->tx_chan)) {
        ret = PTR_ERR(dev->tx_chan);
        pr_err("failed to get tx channel\n");
        return ret;
    }

    dev->rx_chan = dma_request_chan(&pdev->dev, "rx_channel");
    if (IS_ERR(dev->rx_chan)) {
        ret = PTR_ERR(dev->rx_chan);
        pr_err("failed to get rx channel\n");
        goto err_tx_chan;
    }

    /* ================= DMA buffer ================= */
    dev->tx.cpu_addr =
        dma_alloc_coherent(&pdev->dev,
                           test_buf_size,
                           &dev->tx.dma_addr,
                           GFP_KERNEL);
    if (!dev->tx.cpu_addr) {
        ret = -ENOMEM;
        pr_err("dma_alloc_coherent tx failed\n");
        goto err_rx_chan;
    }

    dev->tx.size = test_buf_size;

    dev->rx.cpu_addr =
        dma_alloc_coherent(&pdev->dev,
                           test_buf_size,
                           &dev->rx.dma_addr,
                           GFP_KERNEL);
    if (!dev->rx.cpu_addr) {
        ret = -ENOMEM;
        pr_err("dma_alloc_coherent rx failed\n");
        goto err_tx_buf;
    }

    dev->rx.size = test_buf_size;

    /* ================= char device ================= */
    // ret = alloc_chrdev_region(&dev->devt_ctrl, 0, 3, "axidma0");
    // if (ret) {
    //     pr_err("alloc_chrdev_region failed\n");
    //     goto err_rx_buf;
    // }

    // cdev_init(&dev->devt_ctrl, &ctrl_fops);
    // dev->devt_ctrl.owner = THIS_MODULE;
    // ret = cdev_add(&dev->devt_ctrl, dev->devt_ctrl + 0, 1);
    // if (ret)
    //     goto err_chrdev;

    // cdev_init(&dev->devt_h2c, &c2h_fops);
    // dev->devt_h2c.owner = THIS_MODULE;
    // ret = cdev_add(&dev->devt_h2c, dev->devt_ctrl + 1, 1);
    // if (ret)
    //     goto err_chrdev;

    // cdev_init(&dev->devt_c2h, &c2h_fops);
    // dev->devt_c2h.owner = THIS_MODULE;
    // ret = cdev_add(&dev->devt_c2h, dev->devt_ctrl + 2, 1);
    // if (ret)
    //     goto err_chrdev;



    ret = alloc_chrdev_region(&dev->devt_ctrl, 0, 3, "axidma0");
    if (ret) {
        pr_err("alloc_chrdev_region failed\n");
        goto err_rx_buf;
    }

    /* ---- ctrl cdev ---- */
    cdev_init(&dev->cdev_ctrl, &ctrl_fops);
    dev->cdev_ctrl.owner = THIS_MODULE;

    ret = cdev_add(&dev->cdev_ctrl, dev->devt_ctrl + 2, 1);
    if (ret) {
        pr_err("cdev_add ctrl failed\n");
        goto err_unregister_chrdev;
    }

    /* ---- h2c cdev ---- */
    cdev_init(&dev->cdev_h2c, &h2c_fops);
    dev->cdev_h2c.owner = THIS_MODULE;

    ret = cdev_add(&dev->cdev_h2c, dev->devt_ctrl + 0, 1);
    if (ret) {
        pr_err("cdev_add h2c failed\n");
        goto err_cdev_ctrl;
    }

    /* ---- c2h cdev ---- */
    cdev_init(&dev->cdev_c2h, &c2h_fops);
    dev->cdev_c2h.owner = THIS_MODULE;

    ret = cdev_add(&dev->cdev_c2h, dev->devt_ctrl + 1, 1);
    if (ret) {
        pr_err("cdev_add c2h failed\n");
        goto err_cdev_h2c;
    }


    dev->class = class_create(THIS_MODULE, "axidma0_class");
    if (IS_ERR(dev->class)) {
        ret = PTR_ERR(dev->class);
        goto err_cdev_c2h;
    }

    if (!device_create(dev->class, NULL,
                       dev->devt_ctrl,
                       dev,
                       "axidma0_h2c_0")) {
        ret = -EINVAL;
        goto err_class;
    }

    if (!device_create(dev->class, NULL,
                       dev->devt_ctrl + 1,
                       dev,
                       "axidma0_c2h_0")) {
        ret = -EINVAL;
        goto err_dev_h2c;
    }

    if (!device_create(dev->class, NULL,
                       dev->devt_ctrl + 2,
                       dev,
                       "axidma0_user")) {
        ret = -EINVAL;
        goto err_dev_c2h;
    }

    pr_info("axidma probe success\n");
    return 0;

/* ================= error rollback ================= */

err_dev_c2h:
    device_destroy(dev->class, dev->devt_ctrl + 1);

err_dev_h2c:
    device_destroy(dev->class, dev->devt_ctrl + 0);



err_class:
    class_destroy(dev->class);
    
err_cdev_c2h:
    cdev_del(&dev->cdev_c2h);

err_cdev_h2c:
    cdev_del(&dev->cdev_h2c);

err_cdev_ctrl:
    cdev_del(&dev->cdev_ctrl);

err_unregister_chrdev:
    unregister_chrdev_region(dev->devt_ctrl, 3);

// err_dev2:
//     device_destroy(dev->class, dev->devt_ctrl + 1);

// err_dev1:
//     device_destroy(dev->class, dev->devt_ctrl);

// err_class:
//     class_destroy(dev->class);

// err_chrdev:
//     unregister_chrdev_region(dev->devt_ctrl, 3);

err_rx_buf:
    dma_free_coherent(&pdev->dev,
                      test_buf_size,
                      dev->rx.cpu_addr,
                      dev->rx.dma_addr);

err_tx_buf:
    dma_free_coherent(&pdev->dev,
                      test_buf_size,
                      dev->tx.cpu_addr,
                      dev->tx.dma_addr);

err_rx_chan:
    dma_release_channel(dev->rx_chan);

err_tx_chan:
    dma_release_channel(dev->tx_chan);

    return ret;
}


static int axidma_remove(struct platform_device *pdev)
{
    struct szsywhf_axidma_device *dev = platform_get_drvdata(pdev);

    pr_info("called %s\n", __func__);

    /* stop DMA */
    dmaengine_terminate_all(dev->tx_chan);
    dmaengine_terminate_all(dev->rx_chan);

    /* release DMA channels */
    dma_release_channel(dev->tx_chan);
    dma_release_channel(dev->rx_chan);

    /* free DMA buffers */
    if (dev->tx.cpu_addr)
        dma_free_coherent(&pdev->dev,
                          test_buf_size,
                          dev->tx.cpu_addr,
                          dev->tx.dma_addr);

    if (dev->rx.cpu_addr)
        dma_free_coherent(&pdev->dev,
                          test_buf_size,
                          dev->rx.cpu_addr,
                          dev->rx.dma_addr);

    /* destroy device nodes */
    if (dev->class) {
        device_destroy(dev->class, dev->devt_ctrl + 2);
        device_destroy(dev->class, dev->devt_ctrl + 1);
        device_destroy(dev->class, dev->devt_ctrl);

        class_destroy(dev->class);
    }

    unregister_chrdev_region(dev->devt_ctrl, 3);

    return 0;
}


static const struct of_device_id axidma_of_ids[] = {
    { .compatible = "xlnx,axi-dma-iodev-1.00.a" },
    { .compatible = "shsy,axi-dma-iodev-1.00.a" },
    { .compatible = "szsy,axi-dma-iodev-1.00.a" },
    { .compatible = "xlnx,axidma-chrdev" },
    { /* end */ }
};
MODULE_DEVICE_TABLE(of, axidma_of_ids);

static struct platform_driver axidma_drv = {
    .driver = {
        .name = DRV_MODULE_NAME,
        .of_match_table = axidma_of_ids,
    },
    .probe = axidma_probe,
    .remove = axidma_remove,
};

module_platform_driver(axidma_drv);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("szsywhf <seafly0616@qq.com>");
MODULE_DESCRIPTION("AXI DMA driver (pseudo SG, no float, kernel safe)");