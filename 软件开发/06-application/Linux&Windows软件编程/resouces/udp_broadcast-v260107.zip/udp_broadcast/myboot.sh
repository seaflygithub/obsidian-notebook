#!/bin/bash

# 这是在无法启动图形桌面的时候
# 自动启动网卡并自动获取IP

# install steps:
# step 1: cp myboot.service /etc/systemd/system/
# step 2: cp myboot.sh      /root/
# step 3: chmod a+x         /root/myboot.sh 
# step 4: systemctl daemon-reload
# step 5: systemctl enable myboot

ip link show
ip link set enp12s0 up
dhclient enp12s0

systemctl restart ssh
systemctl restart sshd


