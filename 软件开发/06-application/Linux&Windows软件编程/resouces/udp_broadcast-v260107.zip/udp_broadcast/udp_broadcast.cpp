#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <chrono>
#include <thread>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>

#define LOG_PREFIX_INFO "[INFO]"
#define LOG_PREFIX_ERROR "[ERROR]"
#define LOG_PREFIX_WARN "[WARN]"
#define LOG_MAX_LINES 6000   // 日志文件最大行数
#define LOG_ROLL_LINES 100   // 如果日志行数超过 LOG_MAX_LINES，则滚动日志，删除最前的 LOG_ROLL_LINES 行

// all secs = MAXIMUM_RECONNECT_CNT * RestartSec
// The RestartSec is a var from udp_broadcast.service
#define MAXIMUM_RECONNECT_CNT 12 
#define CURRENT_RECONNECT_CNT "CURRENT_RECONNECT_CNT"

static std::string s_workdir = "/etc/udp_broadcast";
static std::string s_cfgfile = s_workdir + "/config.conf";
static std::string s_logfile = s_workdir + "/logmsg.log";
static std::string s_reconnect_logfile = s_workdir + "/reconnect.log";

static void log_print(const char *prefix, const char *fmt, ...);

// 月份名到数字的映射表（匹配__DATE__的英文缩写）
static int month_name_to_num(const char *month) {
    if (strcmp(month, "Jan") == 0) return 1;
    if (strcmp(month, "Feb") == 0) return 2;
    if (strcmp(month, "Mar") == 0) return 3;
    if (strcmp(month, "Apr") == 0) return 4;
    if (strcmp(month, "May") == 0) return 5;
    if (strcmp(month, "Jun") == 0) return 6;
    if (strcmp(month, "Jul") == 0) return 7;
    if (strcmp(month, "Aug") == 0) return 8;
    if (strcmp(month, "Sep") == 0) return 9;
    if (strcmp(month, "Oct") == 0) return 10;
    if (strcmp(month, "Nov") == 0) return 11;
    if (strcmp(month, "Dec") == 0) return 12;
    return -1; // 无效月份
}

/**
 * 将__DATE__和__TIME__转换为"YYYYMMDD HH:MM"格式的字符串
 * @param date_macro __DATE__宏的值（格式："MMM DD YYYY"，如"Dec 02 2025"）
 * @param time_macro __TIME__宏的值（格式："HH:MM:SS"，如"11:00:00"）
 * @param out_buf 输出缓冲区（至少需16字节："YYYYMMDD HH:MM"共13字符+结束符）
 * @param buf_len 输出缓冲区长度
 * @return 成功返回0，失败返回-1（并打印错误信息）
 */
int format_build_time(const char *date_macro, const char *time_macro, 
                     char *out_buf, size_t buf_len) {
    // 校验输入参数合法性
    if (date_macro == NULL || time_macro == NULL || out_buf == NULL || buf_len < 16) {
        fprintf(stderr, "参数错误：缓冲区过小或指针为空\n");
        return -1;
    }

    // ========== 解析__DATE__（格式：MMM DD YYYY，注意DD可能是1位，如"Dec  2 2025"） ==========
    char month_str[4];
    int day, year;
    // 解析月份(3字符)、日期、年份
    int parse_ret = sscanf(date_macro, "%3s %d %d", month_str, &day, &year);
    if (parse_ret != 3) {
        fprintf(stderr, "__DATE__格式错误：%s（预期格式：MMM DD YYYY）\n", date_macro);
        return -1;
    }

    // 转换月份为数字
    int month = month_name_to_num(month_str);
    if (month == -1 || month < 1 || month > 12) {
        fprintf(stderr, "无效月份：%s\n", month_str);
        return -1;
    }

    // 校验日期合法性（简化校验，仅做范围检查）
    if (day < 1 || day > 31 || year < 1970 || year > 9999) {
        fprintf(stderr, "日期值非法：%d-%d-%d\n", year, month, day);
        return -1;
    }

    // ========== 解析__TIME__（格式：HH:MM:SS） ==========
    int hour, minute, second;
    char sep1, sep2;
    // 解析小时、分隔符、分钟、分隔符、秒
    parse_ret = sscanf(time_macro, "%d%c%d%c%d", &hour, &sep1, &minute, &sep2, &second);
    if (parse_ret != 5 || sep1 != ':' || sep2 != ':') {
        fprintf(stderr, "__TIME__格式错误：%s（预期格式：HH:MM:SS）\n", time_macro);
        return -1;
    }

    // 校验时间合法性
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
        fprintf(stderr, "时间值非法：%d:%d:%d\n", hour, minute, second);
        return -1;
    }

    // ========== 格式化输出（YYYYMMDD HH:MM） ==========
    snprintf(out_buf, buf_len, "%04d%02d%02d %02d:%02d", 
             year, month, day, hour, minute);
    return 0;
}

// 便捷封装：直接使用__DATE__和__TIME__宏
#define GET_BUILD_TIME(buf, len) format_build_time(__DATE__, __TIME__, buf, len)


// 检查文件or目录是否存在
bool file_is_exist(const std::string &dstfile)
{
	int ret = 0;
	std::string cmd = std::string();

	cmd = std::string("test -e ") + dstfile + std::string(" 2>/dev/null 1>&2");
	ret = system(cmd.c_str());
	if (ret != 0)
		return false;

	return true;
}

// 获取文件内容行数
long file_line_cnt(const std::string &dstfile)
{
	// 检查是否存在
	if (!file_is_exist(dstfile))
		return 0;

	std::string cmd;
	cmd = std::string("wc -l ") + dstfile + std::string(" | awk -F ' ' '{print $1}'");

	FILE* pipe = popen(cmd.c_str(), "r");
	if (pipe == NULL)
		return 0;

	char buffer[32] = {0};
	fgets(buffer, sizeof(buffer), pipe);
	pclose(pipe);


	// 字符串转数字
	long line_cnt = atol(buffer);

	return line_cnt;
}


// 从指定文件中,根据key获取val
// split,分隔符,通常为=
std::string file_kv_getval(const std::string &txtfile, const std::string &split, const std::string &key)
{
	// 主要通过外部命令组合获取
	// grep -w "key" txtfile | awk -F '=' '{print $2}'

	std::string cmd;
	cmd = std::string("grep -w '") + key + std::string("' ") + txtfile;
	cmd = cmd + std::string(" | awk -F '") + split + std::string("'");
	cmd = cmd + std::string(" '{print $2}'");
	//printf("cmd = %s\n", cmd.c_str());

	
	FILE* pipe = popen(cmd.c_str(), "r");
	if (pipe == NULL)
		return 0;

	char buffer[512] = {0};
	fgets(buffer, sizeof(buffer), pipe);
	pclose(pipe);

	std::string val = std::string(buffer);
	//log_print("[DEBUG]", "key = %s, val = %s", key.c_str(), val.c_str());
	return val;
}

void log_print(const char *prefix, const char *fmt, ...)
{
	// prefix + date + fmtbuf

	// 首先检查日志文件是否超行数(滚动日志)
	long line_cnt = file_line_cnt(s_logfile);

	if (line_cnt >= LOG_MAX_LINES)
	{
		// 滚动日志,删除最早的几行
		std::string cmd;
		cmd = std::string("tail -n ");
		cmd = cmd + std::to_string(LOG_MAX_LINES - LOG_ROLL_LINES);
		cmd = cmd + std::string(" ") + s_logfile;

		system(cmd.c_str());
	}


	// 格式化字符串
	char fmtbuf[512] = {0};
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(fmtbuf, sizeof(fmtbuf), fmt, ap);
	va_end(ap);


	// 获取时间戳
	char date[32] = {0};
	time_t now = time(NULL);
	struct tm *tm_info = localtime(&now);
	snprintf(date, sizeof(date), "[%04d-%02d-%02d %02d:%02d:%02d]",
	tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
		tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec);

	
	// 最后拼接日志信息
	std::string logmsg;
	logmsg = std::string(prefix) + std::string(date) + std::string(fmtbuf);
	

	// 日志信息输出
	FILE *fp = fopen(s_logfile.c_str(), "a+");
	FILE *output = fp? fp:stdout;
	fprintf(output, "%s\n", logmsg.c_str());
	if (fp) {
		fclose(fp);
		fp = NULL;
	}
	//printf("%s\n", logmsg.c_str());
}

bool file_check_keyexist(const std::string &txtfile, const std::string &key)
{
	// check whether exist or not
	// grep -w "key" txtfile 2>/dev/null 1>&2
	int ret;
	std::string cmd = std::string();
	cmd = std::string("grep -w '") + key + std::string("' ") + txtfile;
	cmd = cmd + std::string(" 2>/dev/null 1>&2");

	ret = system(cmd.c_str());
	if (ret == 0)
		return true;

	return false;
}

void file_kv_append(const std::string &txtfile, const std::string &key, const std::string &val)
{
	std::string cmd = std::string();
	cmd = std::string("echo '") + key + std::string(" = ") + val + std::string("'");
	cmd = cmd + std::string(" >> ") + txtfile;
	printf("cmd = %s\n", cmd.c_str());
	system(cmd.c_str());
}

void file_kv_replace(const std::string &txtfile, const std::string &key, const std::string &val)
{
	std::string cmd = std::string();

	// 先找到匹配的行号
	// grep -nw "key" txtfile | awk -F ':' '{print $1}'
	cmd = std::string("grep -nw '") + key + std::string("' ") + txtfile;
	cmd = cmd + std::string(" | awk -F ':' '{print $1}'");
	cmd = cmd + std::string(" 2>/dev/null");
	//printf("cmd = %s\n", cmd.c_str());
	FILE* pipe = popen(cmd.c_str(), "r");
	if (pipe == NULL)
		return ;
	char buffer[32] = {0};
	fgets(buffer, sizeof(buffer), pipe);
	pclose(pipe);

	// 字符串转数字
	long line = atol(buffer);
	if (line > 0)
	{
        // 比如替换第10行的整行内容: sed -i '10 c\key = val' txtfile
		cmd = std::string("sed -i '") + std::to_string(line) + std::string(" ") 
			+ std::string("c\\") + key + std::string(" = ") + val
			+ std::string("'")
			+ std::string(" ") + txtfile;

		// printf("cmd = %s\n", cmd.c_str());
		system(cmd.c_str());
	}
}

void file_kv_setval(const std::string &txtfile, const std::string &key, const std::string &val)
{
    // 设置键值对，如果没有则追加，如果有则替换

	if (!file_check_keyexist(txtfile, key))
	{
		file_kv_append(txtfile, key, val);

	} else
	{
		file_kv_replace(txtfile, key, val);
	}
}


int reboot_disconnect_timedout(void)
{
	// 为什么要有个超时机制?
	// 因为没有超时机制的情况下,一开机就会导致循环重启,因为刚开机的情况下，网络连接需要时间

	// 读取上一次值
	unsigned long prev_cnt = std::stoull(file_kv_getval(s_reconnect_logfile, "=", CURRENT_RECONNECT_CNT));
	//printf("prev_cnt = %lu\n", prev_cnt);


	// 超时了,可以执行重启动作了
	unsigned long max_recon_cnt = std::stoull(file_kv_getval(s_reconnect_logfile, "=", "MAXIMUM_RECONNECT_CNT"));
	//log_print(LOG_PREFIX_WARN, "prev_cnt = %lu, max_recon_cnt = %lu", prev_cnt, max_recon_cnt);

    if (max_recon_cnt == 0)
    {
        return 0; // 说明用户不想重启系统
    }
    
	if (prev_cnt > max_recon_cnt)
	{
		prev_cnt = 0;
		file_kv_setval(s_reconnect_logfile, "CURRENT_RECONNECT_CNT", std::to_string(prev_cnt));
		system("reboot -f");
	}

	prev_cnt += 1;
	file_kv_setval(s_reconnect_logfile, "CURRENT_RECONNECT_CNT", std::to_string(prev_cnt));
	return 0;
}

int main(int argc, const char *argv[])
{

	// 检查工作目录,不存在就创建
	int ret;
	std::string cmd = std::string();
	if (!file_is_exist(s_workdir))
	{
		std::cout << "create workdir: " << s_workdir << std::endl;
		cmd = std::string("mkdir -p ") + s_workdir;
		ret = system(cmd.c_str());
	}

	// 初始化日志模块
	if (!file_is_exist(s_cfgfile))
	{
		cmd = std::string("touch ") + s_cfgfile;
		ret = system(cmd.c_str());
	}

	if (!file_is_exist(s_logfile))
	{
		cmd = std::string("touch ") + s_logfile;
		ret = system(cmd.c_str());
	}

	if (!file_is_exist(s_reconnect_logfile))
	{
		// write default config
		file_kv_setval(s_reconnect_logfile, CURRENT_RECONNECT_CNT, std::to_string(0));
		file_kv_setval(s_reconnect_logfile, "MAXIMUM_RECONNECT_CNT", std::to_string(MAXIMUM_RECONNECT_CNT));
	}



	char build_time[32] = {0};
	GET_BUILD_TIME(build_time, sizeof(build_time));
	log_print(LOG_PREFIX_INFO, "%s build_time is %s", argv[0], build_time);



    if (argc < 4)
    {
        printf("用法: sudo  %s  <目标端口>  <发送间隔秒数>  <广播包数据载荷>\n", argv[0]);
        return -1;
    }
    unsigned short remote_port = strtol(argv[1], NULL, 0);
    unsigned int sleep_seconds = strtol(argv[2], NULL, 0);
    std::string payload = std::string(argv[3]);
	int slen = -1;
	std::string broadcastData;


    // 创建UDP套接字
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
    {
        std::cerr << "创建套接字失败: " << strerror(errno) << std::endl;
    }

    // 设置套接字选项以允许广播
    int broadcastEnable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, sizeof(broadcastEnable)) < 0)
    {
        std::cerr << "设置广播选项失败: " << strerror(errno) << std::endl;
		slen = -1;
		goto end_of_main;
    }

    // 设置目标地址和端口
    sockaddr_in broadcastAddr;
    memset(&broadcastAddr, 0, sizeof(broadcastAddr));
    broadcastAddr.sin_family = AF_INET;
    broadcastAddr.sin_port = htons(remote_port); // 目标端口
    inet_pton(AF_INET, "255.255.255.255", &broadcastAddr.sin_addr);

    // 广播数据
	broadcastData = 
		std::string("build time: ") + 
		std::string(build_time) + 
		std::string(" ") + payload;

	static bool rebootCntCleaned = false;
    printf("开始每%u秒发送一次广播包...\n", sleep_seconds);
    while (true)
    {
        // 发送广播包
        slen = sendto(sockfd, 
				broadcastData.c_str(), broadcastData.size(), 
				0, (sockaddr *)&broadcastAddr, sizeof(broadcastAddr));
		if (slen <= 0) break;

        // 等待N秒
        std::this_thread::sleep_for(std::chrono::seconds(sleep_seconds));

		// clear reboot timeout
		if (!rebootCntCleaned)
		{
			unsigned long prev_cnt;
			prev_cnt = std::stoull(file_kv_getval(s_reconnect_logfile, "=", CURRENT_RECONNECT_CNT));
			if (prev_cnt != 0)
			{
				prev_cnt = 0;
				file_kv_setval(s_reconnect_logfile, CURRENT_RECONNECT_CNT, std::to_string(prev_cnt));
			}
			rebootCntCleaned = true;
		}

    }

end_of_main:

    // 关闭套接字
    if (sockfd > 0)
	{
		close(sockfd);
		sockfd = 0;
	}

	// 如果突然断网,会立即跳出上述循环
	// 该主程序会退出
	// 但在退出之前,会累加一个计数器（这个计数器存放在 /etc/udp_broadcast/.reboot.log 文件里）
	// 由于是 systemctl 管理该程序, 所以若干秒后该程序又会被拉起来
	// 反正等同于断网了该程序会被 systemctl 反复拉起来,
	// 这个反复拉起来的过程可以理解为反复启动该程序尝试访问网络
	// 每断一次网就累加一个计数器值，
	// 当计数器累加到一定值还没恢复网络，则会触发系统重启
	reboot_disconnect_timedout();
    return (slen>0)? 0:-1;
}
