1.update xxx.service into system
    sudo bash setup.sh 
    sudo systemctl daemon-reload

2.start/stop/restart service
    sudo systemctl start   helloworld.service
    sudo systemctl status  helloworld.service
    sudo systemctl stop    helloworld.service
    sudo systemctl restart helloworld.service

3.force stop service
    sudo systemctl kill    helloworld.service

4.Set autorun/don't autorun after system power on
    sudo systemctl enable  helloworld.service
    sudo systemctl disable helloworld.service

5.uninstall service from system 
    sudo bash setup.sh uninstall


Wireshark filter:
ip.addr == 255.255.255.255 && ip.proto == 17

