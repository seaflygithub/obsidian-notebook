#!/bin/bash
target=udp_broadcast
bindir=/usr/bin
srvdir=/lib/systemd/system
cfgdir=/etc/udp_broadcast

if [ "$1" = "uninstall" ];then
    systemctl kill ${target}.service
	systemctl disable ${target}.service
    rm -rf ${bindir}/${target}.elf 
    rm -rf ${srvdir}/${target}.service
    systemctl daemon-reload
	rm -rf ${cfgdir}
else
	make

    cp -rvf ${target}.elf      ${bindir}
    cp -rvf ${target}.service  ${srvdir}
	chmod a+x ${bindir}/*.elf
	mkdir -p ${cfgdir}

    systemctl daemon-reload
	systemctl disable ${target}.service
	systemctl enable  ${target}.service
    systemctl restart ${target}.service
fi
