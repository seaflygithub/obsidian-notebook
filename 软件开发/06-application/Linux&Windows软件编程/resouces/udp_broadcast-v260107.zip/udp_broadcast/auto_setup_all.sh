sudo bash setup.sh && \
	sudo systemctl disable udp_broadcast && \
	sudo systemctl enable udp_broadcast && \
	sudo systemctl status udp_broadcast
