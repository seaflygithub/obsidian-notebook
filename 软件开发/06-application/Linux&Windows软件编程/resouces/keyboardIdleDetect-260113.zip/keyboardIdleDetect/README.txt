一、发布总共3个文件:
	keyboardIdleDetect.exe         —— 服务主程序
	idleTimeoutPostScript.bat      —— 键盘长时间没按,超时后会执行该脚本
	idleCheckStepScript.bat         —— 在超时检测期间,每次检测,都会执行一次该脚本

二、使用方法
	1、拿到上述文件，找个固定文件夹，把上述文件放到文件夹内；
	2、双击其中的 exe 文件，运行成功后会生成两个新文件，ini 和 log 文件；

三、配置文件
	1、其中的 ini 就是配置文件；
	keyboardNoPressTimeOutSec=7200 表示键盘空闲7200秒后将执行 idleTimeoutPostScript 指定的脚本
	keyboardNoPressTimeStepLenSec=3 表示每3秒检测一次键盘空闲
	keyboardNoPressTimeStepLenSec=3 表示检测期间,顺带执行一下 idleCheckStepScript 指定的脚本
	idleTimeoutPostScript=idleTimeoutPostScript.bat 表示自行指定执行什么文件,可以是.bat, .cmd, .exe 类型
	idleCheckStepScript=idleCheckStepScript.bat 表示每3秒会执行的脚本文件,可以是.bat, .cmd, .exe 类型

四、设置开机启动
	1、按组合键: Ctrl+r，打开运行窗口；
	2、在运行窗口执行如下命令: shell:common startup
	3、把上面 .exe 文件创建快捷方式，然后把快捷方式放到这个启动目录里即可。


五、关于开发工程设置
	1、创建 win32 console 工程
	2、配置工程链接属性: linker --> system --> subsystem --> WINDOWS
	3、配置工程语言属性: C/C++  --> preprocessor --> preprocessor define --> _CONSOLE --> _WINDOWS


