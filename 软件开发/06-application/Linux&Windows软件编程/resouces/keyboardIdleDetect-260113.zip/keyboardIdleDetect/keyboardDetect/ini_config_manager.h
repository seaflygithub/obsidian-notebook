#ifndef INI_CONFIG_MANAGER_CPP_H
#define INI_CONFIG_MANAGER_CPP_H

#include <string>
#include <unordered_map>
#include <mutex>

class IniConfigManager {
    public:
        // 设置指定的 ini 文件
        void setIniFile(const std::string& filePath);
    
        // 新增指定 group 指定 key 配置项
        void addConfig(const std::string& key, const std::string& value, const std::string& group = "General");
    
        // 读取指定 group 的配置值
        std::string getConfig(const std::string& key, const std::string& group = "General");
    
        // 删除指定 group 下的指定配置项
        void deleteConfig(const std::string& key, const std::string& group = "General");
    
    private:
        std::string filePath;
        std::unordered_map<std::string, std::unordered_map<std::string, std::string>> configMap;
        std::mutex mtx;  // 互斥锁，用于线程同步, 同步写配置文件
    
        // 从文件加载配置
        void loadConfig();
    
        // 将配置保存到文件
        void saveConfig();
    };

#endif //INI_CONFIG_MANAGER_CPP_H