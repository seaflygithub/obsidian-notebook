
#include "string_methods_manager.h"

#include <iostream>


// 替换文件名后缀的函数
void StringMethodsManager::strPathReplaceExtension(const std::string& file1, std::string& file2, const std::string& newExtension) {
    size_t lastDotPos = file1.find_last_of('.');
    if (lastDotPos != std::string::npos) {
        // 找到后缀名，替换后缀
        file2 = file1.substr(0, lastDotPos) + newExtension;
    } else {
        // 未找到后缀名，直接添加新后缀
        file2 = file1 + newExtension;
    }
}

// 该函数用于从给定的路径中提取文件名
std::string StringMethodsManager::strPathExtractFileName(const std::string &path)
{
    // 查找路径中最后一个路径分隔符的位置，支持 Unix 和 Windows 系统的分隔符
    size_t found = path.find_last_of("/\\");
    if (found != std::string::npos)
    {
        // 如果找到了路径分隔符，返回分隔符之后的部分作为文件名
        return path.substr(found + 1);
    }
    // 如果没有找到路径分隔符，说明路径本身就是文件名
    return path;
}

// 提取文件路径的函数
std::string StringMethodsManager::strPathExtractPath(const std::string &path) {
    // 查找路径中最后一个路径分隔符的位置，支持 Unix 和 Windows 系统的分隔符
    size_t found = path.find_last_of("/\\");
    if (found != std::string::npos) {
        // 如果找到了路径分隔符，返回分隔符之前的部分作为路径
        return path.substr(0, found);
    }
    // 如果没有找到路径分隔符，说明输入只有文件名，返回空路径
    return "";
}

//删除重复的路径分隔符
std::string StringMethodsManager::strPathRemoveDuplicatePathSeparators(const std::string& path) {
    std::string result;
    for (size_t i = 0; i < path.size(); ++i) {
        // 如果当前字符是路径分隔符
        if (path[i] == '/' || path[i] == '\\') {
            // 跳过连续的分隔符
            while (i + 1 < path.size() && (path[i + 1] == '/' || path[i + 1] == '\\')) {
                ++i;
            }
            // 统一使用 Unix 风格的分隔符
            result += '/';
        } else {
            result += path[i];
        }
    }
    return result;
}

std::string StringMethodsManager::strPathGetExtension(const std::string& path)
{
    // 首先定位到文件名尾部, 然后反向遍历直到找到第一个点(.)

    // 拿到(.)之后的字符串,存到一个新的 std::string 对象里

    // 返回这个对象,如果没找到则返回空对象,方便调用者 empty() 方法判断


    // 步骤1：从路径末尾向前，找到最后一个路径分隔符(\ 或 /)的位置
    size_t lastSepPos = path.find_last_of("\\/");
    // 如果没找到路径分隔符，说明传入的就是纯文件名，起始位置从0开始
    size_t fileNameStart = (lastSepPos == std::string::npos) ? 0 : (lastSepPos + 1);

    // 步骤2：从文件名的起始位置开始，找【最后一个点 .】的位置
    size_t lastDotPos = path.find_last_of('.', std::string::npos);

    // 步骤3：合法性判断 & 截取后缀
    std::string extension;
    // 合法后缀条件：① 找到点 ② 点的位置在文件名之后 ③ 点不能是文件名的最后一个字符
    if (lastDotPos != std::string::npos && lastDotPos > fileNameStart && lastDotPos < path.size() - 1)
    {
        extension = path.substr(lastDotPos + 1);
    }

    return extension;
}



