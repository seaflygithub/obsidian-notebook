/*
Brief:
    The program is used to detect 
	that the computer has not been operated for a long time.
	This applies to computers that require remote control.

Detail:
    If the computer is disconnected from the network
	or the remote control software on the computer is not started,
	the computer cannot be remotely controlled,
	and the keyboard input of the computer cannot be detected for a long time,
	which triggers the computer to automatically restart
	or other automatic operations.

*/


#include <stdio.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>

#include <sstream>
#include <iomanip>

#include <iostream>
#include <fstream>
#include <vector>

int get_file_lines(const std::string& filePath)
{
	std::ifstream fin(filePath, std::ios::in);
	if (!fin.is_open())
	{
		return -1;
	}

	int line_count = 0;
	std::string temp_str;
	while (std::getline(fin, temp_str))
	{
		line_count++;
	}

	fin.close();
	return line_count;
}

std::string tail_n_lines(const std::string& filePath, int n)
{
	std::string ret_content;
	if (n <= 0)
	{
		return ret_content;
	}

	std::ifstream fin(filePath, std::ios::in);
	if (!fin.is_open())
	{
		return ret_content;
	}

	std::vector<std::string> line_buf;
	std::string temp_str;

	// �����߼���ֻ�������µ�n�У�ʼ�ձ����ڴ���ֻ��n������
	while (std::getline(fin, temp_str))
	{
		line_buf.push_back(temp_str);
		if (static_cast<int>(line_buf.size()) > n)
		{
			line_buf.erase(line_buf.begin());
		}
	}

	fin.close();

	// ƴ�ӽ�������ػ��з�(std::getline�ᶪ��ÿ�е�\n)�����һ�в��Ӷ��໻��
	for (size_t i = 0; i < line_buf.size(); ++i)
	{
		ret_content += line_buf[i];
		if (i != line_buf.size() - 1)
		{
			ret_content += "\n";
		}
	}

	return ret_content;
}


#include "string_methods_manager.h"
static StringMethodsManager g_strpath;


#include "ini_config_manager.h"
static IniConfigManager g_ini;
#define INI_SECTION_GENERIC "GenericSettings"          // ��������
#define LOG_FILE_NAME "keyboardIdleDetect.log"

#define OS_WINDOWS



#ifdef OS_WINDOWS
#include <windows.h>
#include <conio.h> //_kbhit() and _getch() are used to detect keystrokes.
#include <shellapi.h> //CommandLineToArgvW(), GetCommandLineW()
#include <tchar.h>
#define simple_delay_ms(ms) Sleep((ms))
#else
#include <unistd.h> //usleep, sleep
#define simple_delay_ms(ms) usleep((ms)*1000)
#endif //OS_WINDOWS

#ifdef OS_WINDOWS
static FILE *g_keyboard_fpLog;
static HHOOK g_keyboard_hHook;

// ��ȡϵͳ����ʱ�䣬���� std::string����ʽ�ϸ�Ϊ��[YYYY-MM-DD HH:MM:SS]
std::string getSystemDateTime()
{
	SYSTEMTIME sysTime = { 0 };
	::GetLocalTime(&sysTime); // ��ȡWindows����ϵͳʱ�䣬�����κ�ƫ�Ƽ��㣬�޿�

	std::ostringstream oss;
	// ��ʽ��ƴ�ӣ��ϸ�ƥ�䡾[��-��-�� ʱ:��:��]����ʽ����0����(���� 2026-01-05 09:08:07)
	oss << "["
		<< std::setw(4) << std::setfill('0') << sysTime.wYear << "-"
		<< std::setw(2) << std::setfill('0') << sysTime.wMonth << "-"
		<< std::setw(2) << std::setfill('0') << sysTime.wDay << " "
		<< std::setw(2) << std::setfill('0') << sysTime.wHour << ":"
		<< std::setw(2) << std::setfill('0') << sysTime.wMinute << ":"
		<< std::setw(2) << std::setfill('0') << sysTime.wSecond
		<< "]";

	return oss.str();
}

// way: 0=rewrite; 1=append
void log_message(int way, const char* format, ...) {

	int where = way ? SEEK_SET : SEEK_END;

	std::string logFileName = g_ini.getConfig("LogFileName", INI_SECTION_GENERIC);
	if (logFileName.empty())
	{
		logFileName = LOG_FILE_NAME;
	}
	if (!g_keyboard_fpLog)
	{
		g_keyboard_fpLog = fopen(logFileName.c_str(), "ab+");
	}

	std::string logMaxLines = g_ini.getConfig("LogMaxLines", INI_SECTION_GENERIC);
	int maxlines = atoi(logMaxLines.c_str());

	if (get_file_lines(logFileName.c_str()) > maxlines)
	{
		std::string last_lines = tail_n_lines(logFileName.c_str(), maxlines - maxlines/10);
		if (!last_lines.empty())
		{
			fclose(g_keyboard_fpLog);
			g_keyboard_fpLog = fopen(logFileName.c_str(), "wb+");
			if (g_keyboard_fpLog)
			{
				fputs(last_lines.c_str(), g_keyboard_fpLog);
				fflush(g_keyboard_fpLog);
			}
		}
	}

	if (g_keyboard_fpLog) {
		va_list args;
		std::string dtStr = getSystemDateTime();

		va_start(args, format);
		fseek(g_keyboard_fpLog, 0, where);

		// ���ַ������⴦��
		if (strnlen(format,512) > 0)
			fprintf(g_keyboard_fpLog, "%s ", dtStr.c_str());
		
		vfprintf(g_keyboard_fpLog, format, args);

		// ���ַ������⴦��
		if (strnlen(format, 512) <= 0)
			fprintf(g_keyboard_fpLog, "\n");
			
		fflush(g_keyboard_fpLog);
		va_end(args);
	}
}

//[keyboardNoPressTimeOutSec] Set the timeout value according to your actual situation.

static unsigned long keyboardNoPressTimeOutSec = 3600; // ����û��⵽�������볬����ʱ��(��)���򴥷��Զ���������������������ȡ�
static unsigned long keyboardNoPressTimeStepLenSec = 3; // ��ⲽ������λ�룬��ÿ��������һ�Ρ�
static unsigned long keyboardPressCounter = 0; // ���̱�����һ�ξͻ��1
static unsigned long keyboardNoPressTimeSec = 0;
static std::string g_workdir = "."; // ����Ŀ¼��Ĭ�ϵ�ǰĿ¼

static FILE *g_mouse_fpLog;
static HHOOK g_mouse_hHook;
static unsigned long mousePressCounter = 0;

LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam);

//https ://blog.csdn.net/new9232/article/details/138617384
int Wchar2Char(wchar_t* wcharStr, char* charStr);
int Char2Wchar(char* charStr, wchar_t* wcharStr);

int Wchar2Char(wchar_t* wcharStr, char* charStr) {
	int len = WideCharToMultiByte(CP_ACP, 0, wcharStr, wcslen(wcharStr), NULL, 0, NULL, NULL);
	WideCharToMultiByte(CP_ACP, 0, wcharStr, wcslen(wcharStr), charStr, len, NULL, NULL);
	charStr[len] = '\0';
	return len;
}

int Char2Wchar(char* charStr, wchar_t* wcharStr) {
	int len = MultiByteToWideChar(CP_ACP, 0, charStr, strlen(charStr), NULL, 0);
	MultiByteToWideChar(CP_ACP, 0, charStr, strlen(charStr), wcharStr, len);
	wcharStr[len] = '\0';
	return len;
}

// ִ���������cmd����
void execute_cmd_hidencmdwindow(const std::string& lpCmdLine)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	ZeroMemory(&pi, sizeof(pi));

	// ִ��cmd����,�����غڴ���
	//CreateProcess(NULL, lpCmdLine, NULL, NULL, 0, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);


	si.cb = sizeof(STARTUPINFO);
	// �ؼ�1���������ش��� + �޿���̨������ȵ���CREATE_NO_WINDOW������
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;

	std::string cmdline = std::string();

	// �ж�Ҫִ�е�Ŀ���ļ�,Ҫô�ǽű��ļ�,Ҫô��exe�ļ�
	// xxx.bat or xxx.cmd or xxx.exe
	if ((g_strpath.strPathGetExtension(lpCmdLine) == "bat") ||
		(g_strpath.strPathGetExtension(lpCmdLine) == "cmd"))
	{
		// ����ǽű��ļ�,����Ҫ��cmdȥ����
		cmdline = std::string("cmd /c ") + lpCmdLine;
	}
	else if (g_strpath.strPathGetExtension(lpCmdLine) == "ps1")
	{
		cmdline = std::string("powershell -File ") + lpCmdLine;
	}
	else
	{
		cmdline = lpCmdLine;
	}
	
	char cmdBuf[256] = { 0 };
	snprintf(cmdBuf, sizeof(cmdBuf), "%s", cmdline.c_str());

	// �ؼ�2���޸����ò��� + ��ȫ��ȫ��־λ��CREATE_NO_WINDOW ���ش���
	BOOL bRet = CreateProcessA(
		NULL,               // ��ָ����ִ��ģ�飬ʹ��������
		cmdBuf,             // �޸���ġ���дchar*�������У�������ͱ���
		NULL,               // ���̾�����̳�
		NULL,               // �߳̾�����̳�
		FALSE,              // ���̳о��
		CREATE_NO_WINDOW,   // ���ģ�����CMD�ڴ���
		NULL,               // ʹ�ø����̵Ļ�������
		NULL,               // ʹ�ø����̵ĵ�ǰĿ¼
		&si,                // ����������Ϣ
		&pi                 // ������Ϣ
	);

	// �ؼ�3��ִ�гɹ��󣬱���رս��̾��+�߳̾���������ڴ�й©
	if (bRet)
	{
		// �ȴ�����ִ�н���(��ѡ������ҵ�����󣺼��˾���ͬ��ִ�У����Ӿ����첽ִ��)
		//WaitForSingleObject(pi.hProcess, INFINITE); 

		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}

}


LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode >= 0) {
		PKBDLLHOOKSTRUCT pKey = (PKBDLLHOOKSTRUCT)lParam;
		switch (wParam) {
		case WM_KEYDOWN:
		{
			keyboardPressCounter += 1;
			//log_message(1, "%lu:WM_KEYDOWN(KEY PRESSED):KEY CODE IS 0x%X\r\n", keyboardPressCounter, pKey->vkCode);
			break;
		}
		//case WM_KEYUP:
		//	fprintf(g_keyboard_fpLog, "Key released: %d\r\n", pKey->vkCode);
		//	fflush(g_keyboard_fpLog);
		//	break;
		}
		
	}
	return CallNextHookEx(g_keyboard_hHook, nCode, wParam, lParam);
}

DWORD WINAPI threadKeyTimeOut(LPVOID lpParam)
{
	std::string strValue = std::string();
	static unsigned long prevTimeoutSecs = 0;
	static std::string prevStepScript = std::string();
	static std::string prevTimeoutScript = std::string();

	while (1)
	{
		simple_delay_ms(1000*keyboardNoPressTimeStepLenSec);
		keyboardNoPressTimeSec += keyboardNoPressTimeStepLenSec;

		// ÿ�γ�ʱ��⣬Ҫִ�еĽű�
		std::string idleCheckStepScript = g_ini.getConfig("idleCheckStepScript", INI_SECTION_GENERIC);
		if (prevStepScript != idleCheckStepScript)
		{
			log_message(1, "changed config idleCheckStepScript value %s to %s\n", prevStepScript.c_str(), idleCheckStepScript.c_str());
			prevStepScript = idleCheckStepScript;
		}
		if (idleCheckStepScript.empty() == false)
		{
			//log_message(1, "Execute idleCheckStepScript: %s\r\n", idleCheckStepScript.c_str());
			//system(idleCheckStepScript.c_str());
			std::string fullpath = g_workdir + std::string("\\") + idleCheckStepScript;
			execute_cmd_hidencmdwindow(fullpath);
		}

		
		if (keyboardPressCounter > 0)
		{
			keyboardNoPressTimeSec = 0;
			keyboardPressCounter = 0;
		}


		// ��ȡ keyboardNoPressTimeOutSec �������ļ���
		strValue = g_ini.getConfig("keyboardNoPressTimeOutSec", INI_SECTION_GENERIC);
		keyboardNoPressTimeOutSec = atoi(strValue.c_str());
		if (prevTimeoutSecs != keyboardNoPressTimeOutSec)
		{
			log_message(1, "changed config keyboardNoPressTimeOutSec %lu to %lu\n", prevTimeoutSecs, keyboardNoPressTimeOutSec);
			prevTimeoutSecs = keyboardNoPressTimeOutSec;
		}

		if (keyboardNoPressTimeSec >= keyboardNoPressTimeOutSec)
		{
			//if keyboard no any input

			//clear old value
			keyboardNoPressTimeSec = 0;

			//Automatic operations
			//���̳�ʱ�䴦��IDLE״̬�����Զ�ִ���ض��ű���������������������ȡ�
			log_message(1, "The keyboard input of the computer cannot be detected for a long time!\r\n");
			//system("shutdown -r -t 0");

			// ��ʱ֮��Ҫִ�еĽű�
			std::string idleTimeoutPostScript = g_ini.getConfig("idleTimeoutPostScript", INI_SECTION_GENERIC);
			if (idleTimeoutPostScript.empty() == false)
			{
				log_message(1, "Execute idleTimeoutPostScript: %s\r\n", idleTimeoutPostScript.c_str());
				//system(idleTimeoutPostScript.c_str());
				std::string fullpath = g_workdir + std::string("\\") + idleTimeoutPostScript;
				execute_cmd_hidencmdwindow(fullpath);
			}
		}
	}
	return 0;
}

LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode >= 0) {
		MSLLHOOKSTRUCT *pMouseStruct = (MSLLHOOKSTRUCT*)lParam;
		log_message(1, "Global mouse event: x=%d, y=%d, flags=0x%x\r\n",
			pMouseStruct->pt.x, pMouseStruct->pt.y, wParam);	}
	//return CallNextHookEx(NULL, nCode, wParam, lParam);//OK
	return CallNextHookEx(g_mouse_hHook, nCode, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {

	// ��ʼ��ini�ļ�
	FILE *fp_ini = fopen("keyboardIdleDetect.ini", "a+"); //ȷ��ini�ļ�����
	if (fp_ini) {
		fclose(fp_ini);
	}
	g_ini.setIniFile("keyboardIdleDetect.ini");


	// ��ӡ����汾��

	log_message(1, "");
	log_message(1, "======================================================\n");
	log_message(1, "keyboardIdleDetect compiled at %s %s\n", __DATE__, __TIME__);


	std::string strValue;
	strValue = g_ini.getConfig("keyboardNoPressTimeOutSec", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		keyboardNoPressTimeOutSec = atoi(strValue.c_str());
		log_message(1, "Read from ini file: keyboardNoPressTimeOutSec = %u\n", keyboardNoPressTimeOutSec);
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("keyboardNoPressTimeOutSec", std::to_string(keyboardNoPressTimeOutSec), INI_SECTION_GENERIC); //Ĭ��60����
		log_message(1, "Write default to ini file: keyboardNoPressTimeOutSec = %u\n", keyboardNoPressTimeOutSec);
	}

	strValue = g_ini.getConfig("logFileName", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		log_message(1, "Read from ini file: logFileName = %s\n", strValue.c_str());
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("logFileName", LOG_FILE_NAME, INI_SECTION_GENERIC); //Ĭ��keyboardIdleDetect.log
		log_message(1, "Write default to ini file: logFileName = %s\n", LOG_FILE_NAME);
	}

	strValue = g_ini.getConfig("logMaxLines", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		log_message(1, "Read from ini file: logMaxLines = %s\n", strValue.c_str());
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("logMaxLines", "10000", INI_SECTION_GENERIC); //Ĭ��10000��
		log_message(1, "Write default to ini file: logMaxLines = %s\n", "10000");
	}


	strValue = g_ini.getConfig("keyboardNoPressTimeStepLenSec", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		keyboardNoPressTimeStepLenSec = atoi(strValue.c_str());
		log_message(1, "Read from ini file: keyboardNoPressTimeStepLenSec = %u\n", keyboardNoPressTimeStepLenSec);
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("keyboardNoPressTimeStepLenSec", std::to_string(keyboardNoPressTimeStepLenSec), INI_SECTION_GENERIC); //Ĭ��1��
		log_message(1, "Write default to ini file: keyboardNoPressTimeStepLenSec = %u\n", keyboardNoPressTimeStepLenSec);
	}

	// ��ʱ֮��Ҫִ�еĽű�
	strValue = g_ini.getConfig("idleTimeoutPostScript", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		log_message(1, "Read from ini file: idleTimeoutPostScript = %s\n", strValue.c_str());
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("idleTimeoutPostScript", "idleTimeoutPostScript.bat", INI_SECTION_GENERIC);
		log_message(1, "Write default to ini file: idleTimeoutPostScript = %s\n", "idleTimeoutPostScript.bat");
	}


	// ÿ�γ�ʱ���Ҫִ�еĽű�
	strValue = g_ini.getConfig("idleCheckStepScript", INI_SECTION_GENERIC);
	if (strValue.empty() == false)
	{
		log_message(1, "Read from ini file: idleCheckStepScript = %s\n", strValue.c_str());
	}
	else
	{
		//д��Ĭ��ֵ��ini�ļ�
		g_ini.addConfig("idleCheckStepScript", "idleCheckStepScript.bat", INI_SECTION_GENERIC);
		log_message(1, "Write default to ini file: idleCheckStepScript = %s\n", "idleCheckStepScript.bat");
	}


	char szWorkDir[MAX_PATH] = { 0 };
	// ��ȡ��ǰ����Ŀ¼��MAX_PATH �㹻�洢�·��
	DWORD dwRet = GetCurrentDirectory(MAX_PATH, szWorkDir);
	if (dwRet > 0 && dwRet <= MAX_PATH)
	{
		log_message(1, "szWorkDir = %s\n", szWorkDir);
		g_workdir = szWorkDir; // ���浱ǰ����Ŀ¼
	}
	else
	{
		log_message(1, "ERROR:GetCurrentDirectory failed, error code = %lu, dwRet=%d\n", GetLastError(), dwRet);
		g_workdir = "."; // �����ȡʧ�ܣ�ʹ�õ�ǰĿ¼��ΪĬ��ֵ
	}
	//exit(0);



	// ��ʱ֮��Ҫ��ʲô��������������������ȣ�����ִ��Ȩ�����ⲿ�ű���
	// ��ʱ֮ǰ��ÿ�γ�ʱ��⣬���˳�ʱ����⣬��Ҫ������ʲô������Ҳ�����ű�������


	//g_keyboard_hHook = SetWindowsHookEx(WH_MOUSE_LL, LowLevelMouseProc, NULL, 0);
	g_keyboard_hHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, NULL, 0);
	if (!g_keyboard_hHook) {
		printf("g_keyboard_hHook failed.\n");
		return -1;
	}


	//Create a thread for timeout detection.
	HANDLE hThread;
	DWORD threadID;
	hThread = CreateThread(NULL, 0, threadKeyTimeOut, NULL, 0, &threadID);
	if (hThread == NULL) {
		printf("CreateThread failed (%d)\n", GetLastError());
		return -1;
	}


	//Run a message loop to keep the hook active.
	MSG msg;
	while (1) 
	{
		GetMessage(&msg, NULL, 0, 0);
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		simple_delay_ms(50);
	}

	UnhookWindowsHookEx(g_keyboard_hHook);
	return 0;
}

#else  //!OS_WINDOWS

#include <fcntl.h>
#include <linux/input.h>
#include <stdio.h>
#include <unistd.h>

int main() {
	int fd = open("/dev/input/event0", O_RDONLY);//make sure which eventX is keyboard
	if (fd < 0) {
		perror("open");
		return 1;
	}

	struct input_event ev;
	while (read(fd, &ev, sizeof(ev)) == sizeof(ev)) {
		if (ev.type == EV_KEY) {
			if (ev.value == 1) printf("Key %d pressed\n", ev.code);
			else if (ev.value == 0) printf("Key %d released\n", ev.code);
		}
	}

	close(fd);
	return 0;
}

#endif //OS_WINDOWS


