#ifndef STRING_METHODS_MANAGER_CPP_H
#define STRING_METHODS_MANAGER_CPP_H

#include <string>

class StringMethodsManager {

public:
    //文件名or路径处理相关的方法
    
    void strPathReplaceExtension(const std::string& file1, std::string& file2, const std::string& newExtension);
    std::string strPathExtractFileName(const std::string &path);
    std::string strPathExtractPath(const std::string &path);
    std::string strPathRemoveDuplicatePathSeparators(const std::string& path);
	std::string strPathGetExtension(const std::string& path);
};

#endif //STRING_METHODS_MANAGER_CPP_H