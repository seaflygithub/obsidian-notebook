@echo off 

::echo shutdown_for_this >> test.txt

shutdown -r -t 30
