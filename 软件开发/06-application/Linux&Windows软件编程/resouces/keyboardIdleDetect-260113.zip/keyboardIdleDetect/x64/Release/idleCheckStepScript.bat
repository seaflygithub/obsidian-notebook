@echo off

taskkill /f /im wps.exe /t
taskkill /f /im wpscloudsvr.exe /t
taskkill /f /im wpscenter.exe /t

